"use client";

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

interface Notification {
  id: number;
  type: string;
  title: string;
  body: string;
  readAt: string | null;
  createdAt: string;
}

/**
 * NotificationsPage
 *
 * Lists notifications for the logged-in user and allows marking them as read.
 * This page uses client-side fetching to get notifications from the API.
 */
export default function NotificationsPage({
  params,
}: {
  params: { locale: string };
}) {
  const { locale } = params;
  const { data: session } = useSession();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  useEffect(() => {
    async function fetchNotifications() {
      try {
        const res = await fetch('/api/notifications');
        if (res.ok) {
          const data: Notification[] = await res.json();
          setNotifications(data);
        }
      } finally {
        setLoading(false);
      }
    }
    fetchNotifications();
  }, []);

  const markAsRead = async (id: number) => {
    const res = await fetch(`/api/notifications/${id}`, { method: 'PATCH' });
    if (res.ok) {
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, readAt: new Date().toISOString() } : n))
      );
    }
  };

  if (!session || !(session as any).user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Link href={`/${locale}/auth/login`} className="text-blue-600 underline">
          {locale === 'ar' ? 'الرجاء تسجيل الدخول' : 'Please login'}
        </Link>
      </div>
    );
  }

  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-4">
        {locale === 'ar' ? 'الإشعارات' : 'Notifications'}
      </h1>
      {loading ? (
        <p>{locale === 'ar' ? 'جاري التحميل...' : 'Loading...'}</p>
      ) : notifications.length === 0 ? (
        <p>{locale === 'ar' ? 'لا توجد إشعارات' : 'No notifications'}</p>
      ) : (
        <div className="bg-white p-4 rounded-lg shadow overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'العنوان' : 'Title'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الرسالة' : 'Message'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'التاريخ' : 'Date'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الحالة' : 'Status'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'إجراء' : 'Action'}
                </th>
              </tr>
            </thead>
            <tbody>
              {notifications.map((n) => (
                <tr key={n.id} className="border-b">
                  <td className="px-2 py-1 font-medium">{n.title}</td>
                  <td className="px-2 py-1">{n.body}</td>
                  <td className="px-2 py-1">
                    {new Date(n.createdAt).toLocaleString(locale === 'ar' ? 'ar' : 'en', {
                      hour12: false,
                    })}
                  </td>
                  <td className="px-2 py-1">
                    {n.readAt
                      ? locale === 'ar'
                        ? 'مقروء'
                        : 'Read'
                      : locale === 'ar'
                      ? 'غير مقروء'
                      : 'Unread'}
                  </td>
                  <td className="px-2 py-1">
                    {!n.readAt && (
                      <button
                        className="px-2 py-1 bg-primary text-white rounded"
                        onClick={() => markAsRead(n.id)}
                      >
                        {locale === 'ar' ? 'تحديد كمقروء' : 'Mark as read'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}