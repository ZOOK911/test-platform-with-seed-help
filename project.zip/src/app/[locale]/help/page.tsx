export default function HelpPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const isAr = locale === 'ar';
  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-bold">
        {isAr ? 'مركز المساعدة' : 'Help Center'}
      </h1>
      <section>
        <h2 className="text-xl font-semibold mb-2">
          {isAr ? 'للمختبرين' : 'For Testers'}
        </h2>
        <p>
          {isAr
            ? 'يمكنك استكشاف الحملات المتاحة، التقديم على الحملات المناسبة لمستواك، ومتابعة مهامك من لوحة التحكم. تأكد من إكمال ملفك الشخصي وإضافة حسابات وسائل التواصل لفتح المزيد من الحملات.'
            : 'Browse available campaigns, apply to those that fit your level, and track your tasks from your dashboard. Make sure to complete your profile and add your social media accounts to unlock more campaigns.'}
        </p>
      </section>
      <section>
        <h2 className="text-xl font-semibold mb-2">
          {isAr ? 'لأصحاب الأعمال' : 'For Businesses'}
        </h2>
        <p>
          {isAr
            ? 'يمكنك إنشاء الحملات وإدارتها، مراجعة الطلبات والمراجعات، والاطلاع على التقارير التفصيلية. تأكد من اختيار خطة الاشتراك المناسبة لعدد الحملات التي تريد تشغيلها.'
            : 'Create and manage campaigns, review applications and feedback, and view detailed reports. Be sure to choose the subscription plan that fits the number of campaigns you want to run.'}
        </p>
      </section>
      <section>
        <h2 className="text-xl font-semibold mb-2">
          {isAr ? 'للإدارة' : 'For Admins'}
        </h2>
        <p>
          {isAr
            ? 'يمكنك مراقبة جميع المستخدمين والحملات، التحقق من المنشورات الاجتماعية، وإدارة عمليات الدفع والتقارير عبر لوحة التحكم الخاصة بالإدارة.'
            : 'Monitor all users and campaigns, verify social posts, and manage payments and reports from the admin dashboard.'}
        </p>
      </section>
      <section>
        <h2 className="text-xl font-semibold mb-2">
          {isAr ? 'الدعم' : 'Support'}
        </h2>
        <p>
          {isAr
            ? 'إذا واجهت أي مشكلة أو احتجت للمساعدة، يمكنك التواصل معنا عبر البريد الإلكتروني المخصص للدعم أو استخدام نموذج التواصل داخل التطبيق.'
            : 'If you encounter any issues or need assistance, you can contact us via the support email or use the contact form within the app.'}
        </p>
      </section>
    </div>
  );
}