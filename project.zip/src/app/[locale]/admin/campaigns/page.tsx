"use client";

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';

interface AdminCampaign {
  id: number;
  name: string;
  business: { id: number; name: string | null } | null;
  status: string;
  testersNeeded: number;
  startDate: string | null;
  endDate: string | null;
  _count: { campaignApplications: number; reviews: number };
}

export default function AdminCampaignsPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const { data: session } = useSession();
  const [campaigns, setCampaigns] = useState<AdminCampaign[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  useEffect(() => {
    async function fetchCampaigns() {
      try {
        const res = await fetch('/api/admin/campaigns');
        if (res.ok) {
          const data: AdminCampaign[] = await res.json();
          setCampaigns(data);
        }
      } finally {
        setLoading(false);
      }
    }
    fetchCampaigns();
  }, []);
  const updateStatus = async (id: number, status: string) => {
    const res = await fetch(`/api/admin/campaigns/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    });
    if (res.ok) {
      setCampaigns((prev) =>
        prev.map((c) => (c.id === id ? { ...c, status } : c))
      );
    }
  };
  if (!session || !(session as any).user || (session.user as any).role !== 'ADMIN') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }
  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-4">
        {locale === 'ar' ? 'الحملات' : 'Campaigns'}
      </h1>
      {loading ? (
        <p>{locale === 'ar' ? 'جاري التحميل...' : 'Loading...'}</p>
      ) : campaigns.length === 0 ? (
        <p>{locale === 'ar' ? 'لا توجد حملات' : 'No campaigns'}</p>
      ) : (
        <div className="bg-white p-4 rounded-lg shadow overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="px-2 py-1 text-left">ID</th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الاسم' : 'Name'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'العمل' : 'Business'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الحالة' : 'Status'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الطلبات' : 'Applications'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'التقييمات' : 'Reviews'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'إجراء' : 'Action'}
                </th>
              </tr>
            </thead>
            <tbody>
              {campaigns.map((c) => (
                <tr key={c.id} className="border-b">
                  <td className="px-2 py-1">{c.id}</td>
                  <td className="px-2 py-1">{c.name}</td>
                  <td className="px-2 py-1">{c.business?.name || '-'}</td>
                  <td className="px-2 py-1">{c.status}</td>
                  <td className="px-2 py-1">{c._count.campaignApplications}</td>
                  <td className="px-2 py-1">{c._count.reviews}</td>
                  <td className="px-2 py-1 space-x-2 rtl:space-x-reverse">
                    {c.status !== 'CLOSED' && (
                      <button
                        className="px-2 py-1 bg-red-500 text-white rounded"
                        onClick={() => updateStatus(c.id, 'CLOSED')}
                      >
                        {locale === 'ar' ? 'إغلاق' : 'Close'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}