"use client";

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

interface AdminUser {
  id: number;
  name: string | null;
  email: string;
  role: string;
  suspended: boolean;
  city: string | null;
  _count: { campaigns: number; campaignApplications: number };
}

export default function AdminUsersPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const { data: session } = useSession();
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  useEffect(() => {
    async function fetchUsers() {
      try {
        const res = await fetch('/api/admin/users');
        if (res.ok) {
          const data: AdminUser[] = await res.json();
          setUsers(data);
        }
      } finally {
        setLoading(false);
      }
    }
    fetchUsers();
  }, []);
  const toggleSuspend = async (id: number, current: boolean) => {
    const res = await fetch(`/api/admin/users/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ suspended: !current }),
    });
    if (res.ok) {
      setUsers((prev) =>
        prev.map((u) => (u.id === id ? { ...u, suspended: !current } : u))
      );
    }
  };
  if (!session || !(session as any).user || (session.user as any).role !== 'ADMIN') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }
  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-4">
        {locale === 'ar' ? 'المستخدمون' : 'Users'}
      </h1>
      {loading ? (
        <p>{locale === 'ar' ? 'جاري التحميل...' : 'Loading...'}</p>
      ) : users.length === 0 ? (
        <p>{locale === 'ar' ? 'لا يوجد مستخدمون' : 'No users'}</p>
      ) : (
        <div className="bg-white p-4 rounded-lg shadow overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="px-2 py-1 text-left">ID</th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الاسم / البريد' : 'Name / Email'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الدور' : 'Role'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'المدينة' : 'City'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الحالة' : 'Status'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'عدد الحملات' : '#Campaigns'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'عدد الطلبات' : '#Applications'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'إجراء' : 'Action'}
                </th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-b">
                  <td className="px-2 py-1">{u.id}</td>
                  <td className="px-2 py-1">
                    {u.name || '-'}{' '}
                    <br />
                    <span className="text-xs text-gray-500">{u.email}</span>
                  </td>
                  <td className="px-2 py-1">{u.role}</td>
                  <td className="px-2 py-1">{u.city || '-'}</td>
                  <td className="px-2 py-1">
                    {u.suspended
                      ? locale === 'ar'
                        ? 'معلق'
                        : 'Suspended'
                      : locale === 'ar'
                      ? 'نشط'
                      : 'Active'}
                  </td>
                  <td className="px-2 py-1">{u._count.campaigns}</td>
                  <td className="px-2 py-1">{u._count.campaignApplications}</td>
                  <td className="px-2 py-1">
                    {u.role !== 'ADMIN' && (
                      <button
                        className="px-2 py-1 rounded bg-primary text-white"
                        onClick={() => toggleSuspend(u.id, u.suspended)}
                      >
                        {u.suspended
                          ? locale === 'ar'
                            ? 'إلغاء التعليق'
                            : 'Unsuspend'
                          : locale === 'ar'
                          ? 'تعليق'
                          : 'Suspend'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}