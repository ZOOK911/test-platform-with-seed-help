"use client";
import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

interface SocialPost {
  id: number;
  platform: string;
  postUrl: string;
  screenshotPath: string;
  verified: boolean;
  tester: { id: number; name: string | null; email: string };
  campaign: { id: number; name: string };
}

export default function AdminSocialPostsPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const { data: session } = useSession();
  const [posts, setPosts] = useState<SocialPost[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchPosts = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/social-posts?verified=false');
      if (res.ok) {
        const data = await res.json();
        setPosts(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (session) {
      fetchPosts();
    }
  }, [session]);

  const verify = async (id: number, verified: boolean) => {
    try {
      const res = await fetch(`/api/social-posts/${id}/verify`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ verified }),
      });
      if (res.ok) {
        fetchPosts();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed');
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (!session || !(session.user as any).role || (session.user as any).role !== 'ADMIN') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }

  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <Link href={`/${locale}/dashboard`} className="text-primary underline">
        {locale === 'ar' ? 'العودة' : 'Back'}
      </Link>
      <div className="bg-white p-6 rounded-lg shadow-md mt-4">
        <h1 className="text-2xl font-semibold mb-4">
          {locale === 'ar' ? 'منشورات اجتماعية بانتظار المراجعة' : 'Pending Social Posts'}
        </h1>
        {loading ? (
          <p>{locale === 'ar' ? 'جارٍ التحميل...' : 'Loading...'}</p>
        ) : posts.length === 0 ? (
          <p>{locale === 'ar' ? 'لا توجد منشورات' : 'No posts to verify'}</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="px-2 py-1 text-left">{locale === 'ar' ? 'المختبر' : 'Tester'}</th>
                  <th className="px-2 py-1 text-left">{locale === 'ar' ? 'الحملة' : 'Campaign'}</th>
                  <th className="px-2 py-1 text-left">{locale === 'ar' ? 'المنصة' : 'Platform'}</th>
                  <th className="px-2 py-1 text-left">URL</th>
                  <th className="px-2 py-1 text-left">{locale === 'ar' ? 'صورة' : 'Screenshot'}</th>
                  <th className="px-2 py-1 text-left">{locale === 'ar' ? 'إجراءات' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody>
                {posts.map((post) => (
                  <tr key={post.id} className="border-b">
                    <td className="px-2 py-1">{post.tester.name || post.tester.email}</td>
                    <td className="px-2 py-1">{post.campaign.name}</td>
                    <td className="px-2 py-1">{post.platform}</td>
                    <td className="px-2 py-1">
                      <a href={post.postUrl} target="_blank" className="text-blue-500 underline">
                        {post.postUrl}
                      </a>
                    </td>
                    <td className="px-2 py-1">
                      {post.screenshotPath ? (
                        <a
                          href={post.screenshotPath}
                          target="_blank"
                          className="text-blue-500 underline"
                        >
                          {locale === 'ar' ? 'عرض' : 'View'}
                        </a>
                      ) : (
                        '-'
                      )}
                    </td>
                    <td className="px-2 py-1 space-x-2 rtl:space-x-reverse">
                      <button
                        onClick={() => verify(post.id, true)}
                        className="px-2 py-1 bg-green-500 text-white rounded text-xs"
                      >
                        {locale === 'ar' ? 'تحقق' : 'Verify'}
                      </button>
                      <button
                        onClick={() => verify(post.id, false)}
                        className="px-2 py-1 bg-red-500 text-white rounded text-xs"
                      >
                        {locale === 'ar' ? 'رفض' : 'Reject'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </main>
  );
}