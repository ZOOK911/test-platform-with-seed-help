import { prisma } from '../../../lib/prisma';
import { authOptions } from '../../api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth/next';
import Link from 'next/link';

export default async function DashboardPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    // Redirect to login if not authenticated
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Link href={`/${locale}/auth/login`} className="text-blue-600 underline">
          {locale === 'ar' ? 'الرجاء تسجيل الدخول' : 'Please login'}
        </Link>
      </div>
    );
  }
  const userId = (session.user as any).id;
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: { businessProfile: true },
  });
  if (!user) {
    return <p>Not found</p>;
  }
  const role = user.role;

  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-6">
        {locale === 'ar' ? 'لوحة التحكم' : 'Dashboard'}
      </h1>
      <div className="bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold mb-4">
          {locale === 'ar'
            ? `مرحبًا، ${user.name || user.email}`
            : `Welcome, ${user.name || user.email}`}
        </h2>
        {/* For each role we display a short description and relevant quick links. */}
        {role === 'TESTER' && (
          <div>
            <p>
              {locale === 'ar'
                ? 'هنا يمكنك متابعة طلباتك واستكشاف حملات جديدة.'
                : 'Here you can follow your applications and discover new campaigns.'}
            </p>
            <div className="mt-4 flex gap-4 rtl:flex-row-reverse flex-wrap">
              <Link
                href={`/${locale}/tester`}
                className="px-4 py-2 rounded-md bg-primary text-white"
              >
                {locale === 'ar' ? 'لوحتي' : 'My Dashboard'}
              </Link>
              <Link
                href={`/${locale}/tester/campaigns`}
                className="px-4 py-2 rounded-md bg-secondary text-white"
              >
                {locale === 'ar' ? 'الحملات' : 'Campaigns'}
              </Link>
              <Link
                href={`/${locale}/tester/wallet`}
                className="px-4 py-2 rounded-md bg-blue-500 text-white"
              >
                {locale === 'ar' ? 'محفظتي' : 'My Wallet'}
              </Link>
              <Link
                href={`/${locale}/notifications`}
                className="px-4 py-2 rounded-md bg-green-600 text-white"
              >
                {locale === 'ar' ? 'الإشعارات' : 'Notifications'}
              </Link>
              <Link
                href={`/${locale}/help`}
                className="px-4 py-2 rounded-md bg-purple-500 text-white"
              >
                {locale === 'ar' ? 'المساعدة' : 'Help'}
              </Link>
            </div>
          </div>
        )}
        {role === 'BUSINESS' && (
          <div>
            <p>
              {locale === 'ar'
                ? 'تابع أداء حملاتك وأدر المدفوعات والتقارير.'
                : 'Monitor your campaign performance, payments and reports.'}
            </p>
            <div className="mt-4 flex gap-4 rtl:flex-row-reverse flex-wrap">
              <Link
                href={`/${locale}/business`}
                className="px-4 py-2 rounded-md bg-primary text-white"
              >
                {locale === 'ar' ? 'لوحة العمل' : 'Dashboard'}
              </Link>
              <Link
                href={`/${locale}/business/campaigns`}
                className="px-4 py-2 rounded-md bg-secondary text-white"
              >
                {locale === 'ar' ? 'حملاتي' : 'My Campaigns'}
              </Link>
              <Link
                href={`/${locale}/business/wallet`}
                className="px-4 py-2 rounded-md bg-blue-500 text-white"
              >
                {locale === 'ar' ? 'المدفوعات' : 'Payments'}
              </Link>
              <Link
                href={`/${locale}/business/reports`}
                className="px-4 py-2 rounded-md bg-green-600 text-white"
              >
                {locale === 'ar' ? 'التقارير' : 'Reports'}
              </Link>
              <Link
                href={`/${locale}/notifications`}
                className="px-4 py-2 rounded-md bg-purple-600 text-white"
              >
                {locale === 'ar' ? 'الإشعارات' : 'Notifications'}
              </Link>
              <Link
                href={`/${locale}/help`}
                className="px-4 py-2 rounded-md bg-purple-500 text-white"
              >
                {locale === 'ar' ? 'المساعدة' : 'Help'}
              </Link>
            </div>
          </div>
        )}
        {role === 'ADMIN' && (
          <div>
            <p>
              {locale === 'ar'
                ? 'قم بإدارة المستخدمين والحملات والتقارير من هنا.'
                : 'Manage users, campaigns and reports from here.'}
            </p>
            <div className="mt-4 flex gap-4 rtl:flex-row-reverse flex-wrap">
              <Link
                href={`/${locale}/admin/users`}
                className="px-4 py-2 rounded-md bg-primary text-white"
              >
                {locale === 'ar' ? 'المستخدمون' : 'Users'}
              </Link>
              <Link
                href={`/${locale}/admin/campaigns`}
                className="px-4 py-2 rounded-md bg-secondary text-white"
              >
                {locale === 'ar' ? 'الحملات' : 'Campaigns'}
              </Link>
              <Link
                href={`/${locale}/admin/social-posts`}
                className="px-4 py-2 rounded-md bg-blue-500 text-white"
              >
                {locale === 'ar' ? 'المنشورات الاجتماعية' : 'Social Posts'}
              </Link>
              <Link
                href={`/${locale}/notifications`}
                className="px-4 py-2 rounded-md bg-green-600 text-white"
              >
                {locale === 'ar' ? 'الإشعارات' : 'Notifications'}
              </Link>
              <Link
                href={`/${locale}/help`}
                className="px-4 py-2 rounded-md bg-purple-500 text-white"
              >
                {locale === 'ar' ? 'المساعدة' : 'Help'}
              </Link>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}