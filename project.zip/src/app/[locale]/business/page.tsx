"use client";

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

interface Metrics {
  totalRevenue: number;
  activeCampaigns: number;
  applicationsThisMonth: number;
  averageRating: number;
}

export default function BusinessDashboardPage({
  params,
}: {
  params: { locale: string };
}) {
  const { locale } = params;
  const { data: session } = useSession();
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    async function fetchMetrics() {
      try {
        const res = await fetch('/api/dashboard/business');
        if (res.ok) {
          const data = await res.json();
          setMetrics(data);
        }
      } finally {
        setLoading(false);
      }
    }
    fetchMetrics();
  }, []);
  // Check authentication and role
  if (!session || !(session as any).user || (session.user as any).role !== 'BUSINESS') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }
  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-6">
        {locale === 'ar' ? 'لوحة عمل التجاري' : 'Business Dashboard'}
      </h1>
      {loading ? (
        <p>{locale === 'ar' ? 'جاري التحميل...' : 'Loading...'}</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-sm text-gray-500">
              {locale === 'ar' ? 'إجمالي المدفوع' : 'Total Paid'}
            </p>
            <p className="text-2xl font-semibold">
              {metrics ? metrics.totalRevenue.toFixed(2) : '0.00'}
            </p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-sm text-gray-500">
              {locale === 'ar' ? 'حملات نشطة' : 'Active Campaigns'}
            </p>
            <p className="text-2xl font-semibold">
              {metrics ? metrics.activeCampaigns : 0}
            </p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-sm text-gray-500">
              {locale === 'ar' ? 'طلبات هذا الشهر' : 'Applications This Month'}
            </p>
            <p className="text-2xl font-semibold">
              {metrics ? metrics.applicationsThisMonth : 0}
            </p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-sm text-gray-500">
              {locale === 'ar' ? 'متوسط التقييم' : 'Average Rating'}
            </p>
            <p className="text-2xl font-semibold">
              {metrics ? metrics.averageRating.toFixed(2) : '0.00'}
            </p>
          </div>
        </div>
      )}
      <div className="flex gap-4 rtl:flex-row-reverse flex-wrap">
        <Link
          href={`/${locale}/business/campaigns`}
          className="px-4 py-2 rounded-md bg-primary text-white"
        >
          {locale === 'ar' ? 'حملاتي' : 'My Campaigns'}
        </Link>
        <Link
          href={`/${locale}/business/campaigns/new`}
          className="px-4 py-2 rounded-md bg-green-600 text-white"
        >
          {locale === 'ar' ? 'إنشاء حملة' : 'Create Campaign'}
        </Link>
        <Link
          href={`/${locale}/business/wallet`}
          className="px-4 py-2 rounded-md bg-secondary text-white"
        >
          {locale === 'ar' ? 'المدفوعات' : 'Payments'}
        </Link>
        <Link
          href={`/${locale}/business/reports`}
          className="px-4 py-2 rounded-md bg-blue-500 text-white"
        >
          {locale === 'ar' ? 'التقارير' : 'Reports'}
        </Link>
        <Link
          href={`/${locale}/business/subscription`}
          className="px-4 py-2 rounded-md bg-purple-600 text-white"
        >
          {locale === 'ar' ? 'الاشتراك' : 'Subscription'}
        </Link>
        <Link
          href={`/${locale}/help`}
          className="px-4 py-2 rounded-md bg-purple-500 text-white"
        >
          {locale === 'ar' ? 'المساعدة' : 'Help'}
        </Link>
      </div>
    </main>
  );
}