import { prisma } from '../../../../../../lib/prisma';
import { authOptions } from '../../../../../api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth/next';
import Link from 'next/link';

// Server component to display a detailed report for a specific campaign.
export default async function CampaignReportPage({
  params,
}: {
  params: { locale: string; id: string };
}) {
  const { locale, id } = params;
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }
  const userRole = (session.user as any).role as string;
  const userId = (session.user as any).id as number;
  const campaignId = parseInt(id, 10);
  if (isNaN(campaignId)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'معرف غير صالح' : 'Invalid ID'}</p>
      </div>
    );
  }
  // Verify access rights: business owner or admin can view
  const campaign = await prisma.campaign.findUnique({
    where: { id: campaignId },
    select: { id: true, businessId: true, name: true },
  });
  if (!campaign) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'الحملة غير موجودة' : 'Campaign not found'}</p>
      </div>
    );
  }
  if (userRole === 'BUSINESS' && campaign.businessId !== userId) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مسموح' : 'Forbidden'}</p>
      </div>
    );
  }
  // Compute summary statistics similar to API
  const [applicantsCount, acceptedCount, completedCount, avgRatingData, ratingGroups, reviews] =
    await Promise.all([
      prisma.campaignApplication.count({ where: { campaignId } }),
      prisma.campaignApplication.count({
        where: {
          campaignId,
          status: { in: ['ACCEPTED', 'AWAITING_REVIEW', 'COMPLETED'] },
        },
      }),
      prisma.campaignApplication.count({ where: { campaignId, status: 'COMPLETED' } }),
      prisma.review.aggregate({
        _avg: { ratingOverall: true },
        where: { campaignId },
      }),
      prisma.review.groupBy({
        by: ['ratingOverall'],
        where: { campaignId },
        _count: { _all: true },
      }),
      prisma.review.findMany({
        where: { campaignId },
        include: {
          tester: true,
        },
      }),
    ]);
  const averageRating = avgRatingData._avg.ratingOverall ?? 0;
  const ratingCounts: Record<number, number> = {};
  for (const group of ratingGroups) {
    ratingCounts[group.ratingOverall] = group._count._all;
  }
  // Compute answers stats and social posts mapping as in API
  const answersAccum: Record<string, any> = {};
  for (const review of reviews) {
    const answers = review.answersJson as any;
    if (answers && typeof answers === 'object') {
      for (const key of Object.keys(answers)) {
        const value = (answers as any)[key];
        if (value === null || value === undefined) continue;
        if (!answersAccum[key]) {
          answersAccum[key] = { sum: 0, count: 0, values: {} };
        }
        if (typeof value === 'number') {
          answersAccum[key].sum += value;
          answersAccum[key].count += 1;
        } else if (typeof value === 'boolean') {
          const boolKey = value ? 'true' : 'false';
          answersAccum[key].values[boolKey] = (answersAccum[key].values[boolKey] || 0) + 1;
          answersAccum[key].count += 1;
        } else if (typeof value === 'string') {
          answersAccum[key].values[value] = (answersAccum[key].values[value] || 0) + 1;
          answersAccum[key].count += 1;
        }
      }
    }
  }
  const processedAnswersStats: Record<string, any> = {};
  for (const key of Object.keys(answersAccum)) {
    const stat = answersAccum[key];
    if (stat.sum !== undefined && stat.count) {
      processedAnswersStats[key] = {
        average: stat.sum / stat.count,
        count: stat.count,
      };
    } else {
      processedAnswersStats[key] = stat.values;
    }
  }
  // Collect social posts for each tester
  const testerIds = reviews.map((r) => r.testerId);
  const postsByTester: Record<number, { platform: string; postUrl: string }[]> = {};
  if (testerIds.length) {
    const posts = await prisma.socialPost.findMany({
      where: { campaignId, testerId: { in: testerIds } },
    });
    for (const p of posts) {
      if (!postsByTester[p.testerId]) postsByTester[p.testerId] = [];
      postsByTester[p.testerId].push({ platform: p.platform, postUrl: p.postUrl });
    }
  }
  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <Link href={`/${locale}/business/reports`} className="text-primary underline">
        {locale === 'ar' ? 'العودة' : 'Back'}
      </Link>
      <h1 className="text-3xl font-bold my-4">{campaign.name}</h1>
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-white p-4 rounded shadow">
          <p className="text-sm text-gray-500">
            {locale === 'ar' ? 'المتقدمون' : 'Applicants'}
          </p>
          <p className="text-2xl font-semibold">{applicantsCount}</p>
        </div>
        <div className="bg-white p-4 rounded shadow">
          <p className="text-sm text-gray-500">
            {locale === 'ar' ? 'القبول' : 'Accepted'}
          </p>
          <p className="text-2xl font-semibold">{acceptedCount}</p>
        </div>
        <div className="bg-white p-4 rounded shadow">
          <p className="text-sm text-gray-500">
            {locale === 'ar' ? 'المكتملة' : 'Completed'}
          </p>
          <p className="text-2xl font-semibold">{completedCount}</p>
        </div>
        <div className="bg-white p-4 rounded shadow">
          <p className="text-sm text-gray-500">
            {locale === 'ar' ? 'متوسط التقييم' : 'Average Rating'}
          </p>
          <p className="text-2xl font-semibold">{averageRating.toFixed(2)}</p>
        </div>
      </div>
      {/* Rating Distribution */}
      <div className="bg-white p-4 rounded shadow mb-6">
        <h2 className="text-xl font-semibold mb-2">
          {locale === 'ar' ? 'توزيع التقييم' : 'Rating Distribution'}
        </h2>
        <table className="min-w-full text-sm">
          <thead>
            <tr className="border-b">
              <th className="px-2 py-1">{locale === 'ar' ? 'التقييم' : 'Rating'}</th>
              <th className="px-2 py-1">{locale === 'ar' ? 'العدد' : 'Count'}</th>
            </tr>
          </thead>
          <tbody>
            {Object.keys(ratingCounts)
              .sort((a, b) => Number(a) - Number(b))
              .map((rating) => (
                <tr key={rating} className="border-b">
                  <td className="px-2 py-1">{rating}</td>
                  <td className="px-2 py-1">{ratingCounts[Number(rating)]}</td>
                </tr>
              ))}
            {Object.keys(ratingCounts).length === 0 && (
              <tr>
                <td colSpan={2} className="text-center py-2">
                  {locale === 'ar' ? 'لا توجد تقييمات بعد' : 'No ratings yet'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {/* Answers stats */}
      {Object.keys(processedAnswersStats).length > 0 && (
        <div className="bg-white p-4 rounded shadow mb-6">
          <h2 className="text-xl font-semibold mb-2">
            {locale === 'ar' ? 'إحصاءات الأسئلة' : 'Question Statistics'}
          </h2>
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="px-2 py-1">{locale === 'ar' ? 'السؤال' : 'Question'}</th>
                <th className="px-2 py-1">{locale === 'ar' ? 'القيمة' : 'Value'}</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(processedAnswersStats).map(([key, val]) => (
                <tr key={key} className="border-b">
                  <td className="px-2 py-1">{key}</td>
                  <td className="px-2 py-1">
                    {typeof (val as any).average === 'number'
                      ? `${(val as any).average.toFixed(2)} (${(val as any).count})`
                      : Object.entries(val as any)
                          .map(([k, v]) => `${k}: ${v}`)
                          .join(', ')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {/* Testers table */}
      <div className="bg-white p-4 rounded shadow">
        <h2 className="text-xl font-semibold mb-2">
          {locale === 'ar' ? 'المختبرون' : 'Testers'}
        </h2>
        <table className="min-w-full text-sm">
          <thead>
            <tr className="border-b">
              <th className="px-2 py-1 text-left">
                {locale === 'ar' ? 'الاسم' : 'Name'}
              </th>
              <th className="px-2 py-1 text-left">
                {locale === 'ar' ? 'المستوى' : 'Level'}
              </th>
              <th className="px-2 py-1 text-left">
                {locale === 'ar' ? 'المدينة' : 'City'}
              </th>
              <th className="px-2 py-1 text-left">
                {locale === 'ar' ? 'التقييم' : 'Rating'}
              </th>
              <th className="px-2 py-1 text-left">
                {locale === 'ar' ? 'التعليق' : 'Comment'}
              </th>
              <th className="px-2 py-1 text-left">
                {locale === 'ar' ? 'المنشورات' : 'Posts'}
              </th>
            </tr>
          </thead>
          <tbody>
            {reviews.map((review) => (
              <tr key={review.testerId} className="border-b">
                <td className="px-2 py-1">
                  {review.tester.name || review.tester.email}
                </td>
                <td className="px-2 py-1">{review.tester.level ?? '-'}</td>
                <td className="px-2 py-1">{review.tester.city || '-'}</td>
                <td className="px-2 py-1">{review.ratingOverall}</td>
                <td className="px-2 py-1">{review.comment || '-'}</td>
                <td className="px-2 py-1">
                  {postsByTester[review.testerId] && postsByTester[review.testerId].length
                    ? postsByTester[review.testerId].map((p) => (
                        <a
                          key={p.postUrl}
                          href={p.postUrl}
                          className="text-blue-600 underline block"
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          {p.platform}
                        </a>
                      ))
                    : '-'}
                </td>
              </tr>
            ))}
            {reviews.length === 0 && (
              <tr>
                <td colSpan={6} className="text-center py-2">
                  {locale === 'ar' ? 'لا يوجد مراجعات' : 'No reviews yet'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </main>
  );
}