import { prisma } from '../../../../../lib/prisma';
import { authOptions } from '../../../../api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth/next';
import Link from 'next/link';
import dynamic from 'next/dynamic';

// Dynamically import the client-side suggested testers table to avoid SSR issues
const SuggestedTestersTable = dynamic(
  () => import('../../../../../components/SuggestedTestersTable'),
  { ssr: false }
);

// Dynamically import the client-side applications table to avoid SSR issues
const BusinessApplicationsTable = dynamic(() => import('../../../../../components/BusinessApplicationsTable'), { ssr: false });

export default async function BusinessCampaignDetailPage({
  params,
}: {
  params: { locale: string; id: string };
}) {
  const { locale, id } = params;
  const session = await getServerSession(authOptions);
  if (!session || !session.user || (session.user as any).role !== 'BUSINESS') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }
  const businessId = (session.user as any).id;
  const campaignId = parseInt(id);
  const campaign = await prisma.campaign.findUnique({
    where: { id: campaignId, businessId },
    include: {
      applications: true,
    },
  });
  if (!campaign) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'الحملة غير موجودة' : 'Campaign not found'}</p>
      </div>
    );
  }
  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <Link href={`/${locale}/business/campaigns`} className="text-primary underline">
        {locale === 'ar' ? 'العودة' : 'Back'}
      </Link>
      <div className="bg-white p-6 rounded-lg shadow-md mt-4">
        <h1 className="text-2xl font-semibold mb-4">{campaign.name}</h1>
        <p className="mb-2 text-gray-700">{campaign.description}</p>
        <h2 className="text-xl font-semibold mb-2">
          {locale === 'ar' ? 'المتقدمون' : 'Applicants'} ({campaign.applications.length})
        </h2>
        {/* Render a client-side applications table for managing applicants */}
        <BusinessApplicationsTable campaignId={campaignId} locale={locale} />

        {/* Suggested testers section */}
        <SuggestedTestersTable campaignId={campaignId} locale={locale} />

        {/* Link to campaign report */}
        <div className="mt-6">
          <Link
            href={`/${locale}/business/campaigns/${campaignId}/report`}
            className="text-blue-600 underline"
          >
            {locale === 'ar' ? 'عرض التقرير' : 'View Report'}
          </Link>
        </div>
      </div>
    </main>
  );
}