import { prisma } from '../../../../lib/prisma';
import { authOptions } from '../../../api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth/next';
import Link from 'next/link';

export default async function BusinessCampaignsPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const session = await getServerSession(authOptions);
  if (!session || !session.user || (session.user as any).role !== 'BUSINESS') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }
  const businessId = (session.user as any).id;
  const campaigns = await prisma.campaign.findMany({
    where: { businessId },
    include: {
      applications: true,
    },
    orderBy: { createdAt: 'desc' },
  });
  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-4">
        {locale === 'ar' ? 'حملاتي' : 'My Campaigns'}
      </h1>
      <div className="mb-4">
        <Link
          href={`/${locale}/business/campaigns/new`}
          className="px-4 py-2 bg-primary text-white rounded-md"
        >
          {locale === 'ar' ? 'إنشاء حملة' : 'Create Campaign'}
        </Link>
      </div>
      <div className="grid gap-4">
        {campaigns.map((c) => (
          <div key={c.id} className="bg-white p-4 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-2">{c.name}</h2>
            <p className="text-sm text-gray-500 mb-1">
              {locale === 'ar' ? 'الحالة' : 'Status'}: {c.status}
            </p>
            <p className="text-sm text-gray-500 mb-1">
              {locale === 'ar' ? 'عدد المتقدمين' : 'Applicants'}: {c.applications.length}
            </p>
            <div className="mt-2">
              <Link
                href={`/${locale}/business/campaigns/${c.id}`}
                className="text-primary underline"
              >
                {locale === 'ar' ? 'إدارة' : 'Manage'}
              </Link>
            </div>
          </div>
        ))}
        {campaigns.length === 0 && (
          <p>{locale === 'ar' ? 'لم تقم بإنشاء حملات بعد' : 'You have not created any campaigns yet.'}</p>
        )}
      </div>
    </main>
  );
}