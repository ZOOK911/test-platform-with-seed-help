"use client";
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

export default function NewCampaignPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const router = useRouter();
  const { data: session } = useSession();
  const [form, setForm] = useState({
    name: '',
    type: 'PRODUCT',
    description: '',
    testersNeeded: 1,
    rewardType: 'PRODUCT',
    rewardDescription: '',
    startDate: '',
    endDate: '',
  });
  const [error, setError] = useState<string | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const res = await fetch('/api/campaigns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          testersNeeded: Number(form.testersNeeded),
          socialRequired: false,
          socialPlatforms: [],
          startDate: form.startDate,
          endDate: form.endDate,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Failed to create campaign');
      } else {
        router.push(`/${locale}/business/campaigns`);
      }
    } catch (err: any) {
      setError(err.message);
    }
  };
  if (!session || (session.user as any).role !== 'BUSINESS') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }
  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <Link href={`/${locale}/business/campaigns`} className="text-primary underline">
        {locale === 'ar' ? 'العودة' : 'Back'}
      </Link>
      <div className="bg-white p-6 rounded-lg shadow-md mt-4 max-w-2xl mx-auto">
        <h1 className="text-2xl font-semibold mb-4">
          {locale === 'ar' ? 'إنشاء حملة جديدة' : 'Create New Campaign'}
        </h1>
        {error && <p className="text-red-600 mb-2">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm mb-1" htmlFor="name">
              {locale === 'ar' ? 'اسم الحملة' : 'Campaign Name'}
            </label>
            <input
              id="name"
              name="name"
              type="text"
              value={form.name}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
              required
            />
          </div>
          <div>
            <label className="block text-sm mb-1" htmlFor="type">
              {locale === 'ar' ? 'نوع الحملة' : 'Campaign Type'}
            </label>
            <select
              id="type"
              name="type"
              value={form.type}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="PRODUCT">{locale === 'ar' ? 'منتج' : 'Product'}</option>
              <option value="VENUE">{locale === 'ar' ? 'مكان' : 'Venue'}</option>
            </select>
          </div>
          <div>
            <label className="block text-sm mb-1" htmlFor="description">
              {locale === 'ar' ? 'الوصف' : 'Description'}
            </label>
            <textarea
              id="description"
              name="description"
              value={form.description}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
              rows={3}
            />
          </div>
          <div>
            <label className="block text-sm mb-1" htmlFor="testersNeeded">
              {locale === 'ar' ? 'عدد المختبرين المطلوب' : 'Testers Needed'}
            </label>
            <input
              id="testersNeeded"
              name="testersNeeded"
              type="number"
              value={form.testersNeeded}
              onChange={handleChange}
              min={1}
              className="w-full border rounded-md px-3 py-2"
            />
          </div>
          <div>
            <label className="block text-sm mb-1" htmlFor="rewardType">
              {locale === 'ar' ? 'نوع المكافأة' : 'Reward Type'}
            </label>
            <select
              id="rewardType"
              name="rewardType"
              value={form.rewardType}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="PRODUCT">{locale === 'ar' ? 'منتج' : 'Product'}</option>
              <option value="VISIT">{locale === 'ar' ? 'زيارة' : 'Visit'}</option>
              <option value="DISCOUNT">{locale === 'ar' ? 'خصم' : 'Discount'}</option>
              <option value="MONEY">{locale === 'ar' ? 'مال' : 'Money'}</option>
            </select>
          </div>
          <div>
            <label className="block text-sm mb-1" htmlFor="rewardDescription">
              {locale === 'ar' ? 'وصف المكافأة' : 'Reward Description'}
            </label>
            <input
              id="rewardDescription"
              name="rewardDescription"
              type="text"
              value={form.rewardDescription}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm mb-1" htmlFor="startDate">
                {locale === 'ar' ? 'تاريخ البدء' : 'Start Date'}
              </label>
              <input
                id="startDate"
                name="startDate"
                type="date"
                value={form.startDate}
                onChange={handleChange}
                className="w-full border rounded-md px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-sm mb-1" htmlFor="endDate">
                {locale === 'ar' ? 'تاريخ الانتهاء' : 'End Date'}
              </label>
              <input
                id="endDate"
                name="endDate"
                type="date"
                value={form.endDate}
                onChange={handleChange}
                className="w-full border rounded-md px-3 py-2"
              />
            </div>
          </div>
          <button
            type="submit"
            className="w-full bg-primary text-white py-2 rounded-md"
          >
            {locale === 'ar' ? 'حفظ' : 'Save'}
          </button>
        </form>
      </div>
    </main>
  );
}