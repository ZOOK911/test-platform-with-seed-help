"use client";

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';

interface Plan {
  type: string;
  name: string;
  price: number;
  currency: string;
  campaignsLimit: number | null;
  features: string[];
}

interface SubscriptionInfo {
  id: number;
  plan: string;
  status: string;
  startsAt: string;
  expiresAt: string | null;
}

interface Invoice {
  id: number;
  amount: number;
  currency: string;
  status: string;
  dueAt: string;
  paidAt: string | null;
  createdAt: string;
}

export default function SubscriptionPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const { data: session, status } = useSession();
  const [loading, setLoading] = useState(true);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [currentPlan, setCurrentPlan] = useState<Plan | null>(null);
  const [subscription, setSubscription] = useState<SubscriptionInfo | null>(null);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Fetch plans, current subscription and invoices on mount
  useEffect(() => {
    async function fetchData() {
      try {
        const resPlans = await fetch('/api/subscriptions/plans');
        const plansData: Plan[] = await resPlans.json();
        setPlans(plansData);
        const resSub = await fetch('/api/subscriptions/me');
        if (resSub.ok) {
          const subData = await resSub.json();
          setCurrentPlan(subData.plan);
          setSubscription(subData.subscription);
        }
        const resInvoices = await fetch('/api/invoices/me');
        if (resInvoices.ok) {
          const invData = await resInvoices.json();
          setInvoices(invData);
        }
      } catch (err) {
        console.error(err);
        setError('Failed to load subscription data');
      } finally {
        setLoading(false);
      }
    }
    if (status === 'authenticated') {
      fetchData();
    }
  }, [status]);

  async function handleUpgrade(planType: string) {
    if (!confirm(locale === 'ar' ? 'هل أنت متأكد من الترقية؟' : 'Are you sure you want to upgrade?')) {
      return;
    }
    try {
      const res = await fetch('/api/subscriptions/upgrade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ planType }),
      });
      if (!res.ok) {
        const errJson = await res.json();
        alert(errJson.error || 'Upgrade failed');
        return;
      }
      const data = await res.json();
      // Refresh subscription and invoices after upgrade
      setSubscription(data.subscription);
      setCurrentPlan(plans.find((p) => p.type === data.subscription.plan) || null);
      if (data.invoice) {
        setInvoices((prev) => [data.invoice, ...prev]);
      }
      alert(locale === 'ar' ? 'تم الترقية بنجاح' : 'Upgrade successful');
    } catch (err) {
      alert(locale === 'ar' ? 'فشلت عملية الترقية' : 'Upgrade failed');
    }
  }

  async function handlePay(invoiceId: number) {
    if (!confirm(locale === 'ar' ? 'هل تريد وضع علامة مدفوع؟' : 'Mark as paid?')) {
      return;
    }
    try {
      const res = await fetch(`/api/invoices/${invoiceId}/pay`, { method: 'POST' });
      if (!res.ok) {
        const errJson = await res.json();
        alert(errJson.error || 'Failed to mark invoice');
        return;
      }
      const updated = await res.json();
      setInvoices((prev) =>
        prev.map((inv) => (inv.id === invoiceId ? { ...inv, status: updated.status, paidAt: updated.paidAt } : inv))
      );
      alert(locale === 'ar' ? 'تم تحديث الفاتورة' : 'Invoice updated');
    } catch (err) {
      alert(locale === 'ar' ? 'حدث خطأ عند تحديث الفاتورة' : 'Error updating invoice');
    }
  }

  if (status === 'loading' || loading) {
    return <p className="p-4">{locale === 'ar' ? 'جاري التحميل...' : 'Loading...'}</p>;
  }
  if (error) {
    return <p className="p-4 text-red-500">{error}</p>;
  }
  // Only allow business users
  if (session?.user && (session.user as any).role !== 'BUSINESS') {
    return (
      <p className="p-4 text-red-500">
        {locale === 'ar'
          ? 'هذه الصفحة مخصصة لحسابات الأعمال فقط'
          : 'This page is only available for business accounts'}
      </p>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-2xl font-bold">
        {locale === 'ar' ? 'الاشتراك والخطط' : 'Subscription & Plans'}
      </h1>
      {currentPlan && (
        <div className="bg-white rounded shadow p-4">
          <h2 className="text-xl font-semibold mb-2">
            {locale === 'ar' ? 'خطة الحالية' : 'Current Plan'}
          </h2>
          <p className="mb-2">
            {locale === 'ar' ? 'الاسم:' : 'Name:'} {currentPlan.name}
          </p>
          <p className="mb-2">
            {locale === 'ar' ? 'السعر:' : 'Price:'}{' '}
            {currentPlan.price === 0
              ? locale === 'ar'
                ? 'مجانية'
                : 'Free'
              : `${currentPlan.price} ${currentPlan.currency}/شهريًا`}
          </p>
          <p className="mb-2">
            {locale === 'ar' ? 'الحد الأقصى للحملات النشطة:' : 'Active campaigns limit:'}{' '}
            {currentPlan.campaignsLimit === null
              ? locale === 'ar'
                ? 'غير محدود'
                : 'Unlimited'
              : currentPlan.campaignsLimit}
          </p>
          {subscription && subscription.expiresAt && (
            <p className="mb-2">
              {locale === 'ar' ? 'تنتهي في:' : 'Expires at:'}{' '}
              {new Date(subscription.expiresAt).toLocaleDateString(locale)}
            </p>
          )}
          <ul className="list-disc ml-5 mt-2">
            {currentPlan.features.map((feature, idx) => (
              <li key={idx}>{feature}</li>
            ))}
          </ul>
        </div>
      )}
      <div>
        <h2 className="text-xl font-semibold mb-2">
          {locale === 'ar' ? 'خطط أخرى' : 'Other Plans'}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {plans
            .filter((p) => !currentPlan || p.type !== currentPlan.type)
            .map((plan) => (
              <div key={plan.type} className="bg-white rounded shadow p-4 flex flex-col">
                <h3 className="text-lg font-semibold">{plan.name}</h3>
                <p className="my-1">
                  {plan.price === 0
                    ? locale === 'ar'
                      ? 'مجانية'
                      : 'Free'
                    : `${plan.price} ${plan.currency}/شهريًا`}
                </p>
                <p className="my-1">
                  {locale === 'ar' ? 'الحد الأقصى:' : 'Limit:'}{' '}
                  {plan.campaignsLimit === null
                    ? locale === 'ar'
                      ? 'غير محدود'
                      : 'Unlimited'
                    : plan.campaignsLimit}
                </p>
                <ul className="list-disc ml-5 mt-2 flex-grow">
                  {plan.features.map((feature, idx) => (
                    <li key={idx}>{feature}</li>
                  ))}
                </ul>
                <button
                  onClick={() => handleUpgrade(plan.type)}
                  className="mt-4 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded"
                >
                  {locale === 'ar' ? 'ترقية' : 'Upgrade'}
                </button>
              </div>
            ))}
        </div>
      </div>
      <div>
        <h2 className="text-xl font-semibold mb-2">
          {locale === 'ar' ? 'الفواتير' : 'Invoices'}
        </h2>
        {invoices.length === 0 ? (
          <p>{locale === 'ar' ? 'لا يوجد فواتير' : 'No invoices'}</p>
        ) : (
          <div className="overflow-x-auto bg-white rounded shadow">
            <table className="min-w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="px-2 py-1 text-left">
                    {locale === 'ar' ? 'المبلغ' : 'Amount'}
                  </th>
                  <th className="px-2 py-1 text-left">
                    {locale === 'ar' ? 'العملة' : 'Currency'}
                  </th>
                  <th className="px-2 py-1 text-left">
                    {locale === 'ar' ? 'الحالة' : 'Status'}
                  </th>
                  <th className="px-2 py-1 text-left">
                    {locale === 'ar' ? 'تاريخ الاستحقاق' : 'Due at'}
                  </th>
                  <th className="px-2 py-1 text-left">
                    {locale === 'ar' ? 'تاريخ الدفع' : 'Paid at'}
                  </th>
                  <th className="px-2 py-1"></th>
                </tr>
              </thead>
              <tbody>
                {invoices.map((inv) => (
                  <tr key={inv.id} className="border-b">
                    <td className="px-2 py-1">{inv.amount}</td>
                    <td className="px-2 py-1">{inv.currency}</td>
                    <td className="px-2 py-1">{inv.status}</td>
                    <td className="px-2 py-1">
                      {new Date(inv.dueAt).toLocaleDateString(locale)}
                    </td>
                    <td className="px-2 py-1">
                      {inv.paidAt ? new Date(inv.paidAt).toLocaleDateString(locale) : '-'}
                    </td>
                    <td className="px-2 py-1">
                      {inv.status === 'DUE' && (
                        <button
                          onClick={() => handlePay(inv.id)}
                          className="bg-green-600 hover:bg-green-700 text-white py-1 px-3 rounded"
                        >
                          {locale === 'ar' ? 'وضع علامة مدفوع' : 'Mark as Paid'}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}