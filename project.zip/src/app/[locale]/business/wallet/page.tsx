"use client";

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';

interface Transaction {
  id: number;
  amount: number;
  currency: string;
  status: string;
  method: string | null;
  note: string | null;
  campaign: { id: number; name: string | null } | null;
  user: { id: number; name: string | null; email: string };
  createdAt: string;
}

export default function BusinessWalletPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const { data: session } = useSession();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const fetchTransactions = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/wallet-transactions');
      if (res.ok) {
        const data: Transaction[] = await res.json();
        setTransactions(data);
      }
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchTransactions();
  }, []);
  const markAsPaid = async (id: number) => {
    const method = prompt(
      locale === 'ar'
        ? 'أدخل طريقة الدفع (مثلاً: bank_transfer)'
        : 'Enter payment method (e.g., bank_transfer)'
    );
    if (!method) return;
    const note = prompt(locale === 'ar' ? 'أدخل ملاحظة (اختياري)' : 'Enter a note (optional)') || '';
    const res = await fetch(`/api/wallet-transactions/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ method, note }),
    });
    if (res.ok) {
      // update state
      await fetchTransactions();
    } else {
      alert(locale === 'ar' ? 'فشل التحديث' : 'Failed to update');
    }
  };
  if (!session || !(session as any).user || (session.user as any).role !== 'BUSINESS') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }
  const totalDue = transactions
    .filter((t) => t.status === 'DUE')
    .reduce((sum, t) => sum + t.amount, 0);
  const totalPaid = transactions
    .filter((t) => t.status === 'PAID')
    .reduce((sum, t) => sum + t.amount, 0);
  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-4">
        {locale === 'ar' ? 'المدفوعات' : 'Payments'}
      </h1>
      <div className="mb-4 grid grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-sm text-gray-500">
            {locale === 'ar' ? 'إجمالي المستحق' : 'Total Due'}
          </p>
          <p className="text-2xl font-semibold">{totalDue}</p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <p className="text-sm text-gray-500">
            {locale === 'ar' ? 'إجمالي المدفوع' : 'Total Paid'}
          </p>
          <p className="text-2xl font-semibold">{totalPaid}</p>
        </div>
      </div>
      {loading ? (
        <p>{locale === 'ar' ? 'جاري التحميل...' : 'Loading...'}</p>
      ) : (
        <div className="bg-white p-4 rounded-lg shadow overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'المؤثر' : 'Tester'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الحملة' : 'Campaign'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'المبلغ' : 'Amount'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الحالة' : 'Status'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'طريقة' : 'Method'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'ملاحظة' : 'Note'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'إجراء' : 'Action'}
                </th>
              </tr>
            </thead>
            <tbody>
              {transactions.map((t) => (
                <tr key={t.id} className="border-b">
                  <td className="px-2 py-1">{t.user.name || t.user.email}</td>
                  <td className="px-2 py-1">{t.campaign?.name}</td>
                  <td className="px-2 py-1">
                    {t.amount} {t.currency}
                  </td>
                  <td className="px-2 py-1">
                    {t.status === 'DUE'
                      ? locale === 'ar'
                        ? 'مستحق'
                        : 'DUE'
                      : locale === 'ar'
                      ? 'مدفوع'
                      : 'PAID'}
                  </td>
                  <td className="px-2 py-1">{t.method || '-'}</td>
                  <td className="px-2 py-1">{t.note || '-'}</td>
                  <td className="px-2 py-1">
                    {t.status === 'DUE' && (
                      <button
                        className="px-2 py-1 bg-green-600 text-white rounded"
                        onClick={() => markAsPaid(t.id)}
                      >
                        {locale === 'ar' ? 'تحديد كمَدْفوع' : 'Mark as Paid'}
                      </button>
                    )}
                  </td>
                </tr>
              ))}
              {transactions.length === 0 && (
                <tr>
                  <td colSpan={7} className="text-center py-2">
                    {locale === 'ar' ? 'لا توجد معاملات بعد' : 'No transactions yet'}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </main>
  );
}