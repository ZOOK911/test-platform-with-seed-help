import { prisma } from '../../../../../lib/prisma';
import { authOptions } from '../../../api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth/next';
import Link from 'next/link';

// Server component to display a list of campaigns for which the business can view reports.
export default async function BusinessReportsPage({
  params,
}: {
  params: { locale: string };
}) {
  const { locale } = params;
  const session = await getServerSession(authOptions);
  if (!session || !session.user || (session.user as any).role !== 'BUSINESS') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }
  const businessId = (session.user as any).id as number;
  const campaigns = await prisma.campaign.findMany({
    where: { businessId },
    orderBy: { createdAt: 'desc' },
    select: { id: true, name: true, status: true },
  });
  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-6">
        {locale === 'ar' ? 'التقارير' : 'Reports'}
      </h1>
      <div className="bg-white p-4 rounded-lg shadow">
        {campaigns.length === 0 ? (
          <p>{locale === 'ar' ? 'لا توجد حملات' : 'No campaigns'}</p>
        ) : (
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الحملة' : 'Campaign'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الحالة' : 'Status'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'التقرير' : 'Report'}
                </th>
              </tr>
            </thead>
            <tbody>
              {campaigns.map((c) => (
                <tr key={c.id} className="border-b">
                  <td className="px-2 py-1">{c.name}</td>
                  <td className="px-2 py-1">{c.status}</td>
                  <td className="px-2 py-1">
                    <Link
                      href={`/${locale}/business/campaigns/${c.id}/report`}
                      className="text-blue-600 underline"
                    >
                      {locale === 'ar' ? 'عرض' : 'View'}
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </main>
  );
}