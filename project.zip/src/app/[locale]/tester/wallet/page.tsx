import { prisma } from '../../../../lib/prisma';
import { authOptions } from '../../../api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth/next';

export default async function TesterWalletPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const session = await getServerSession(authOptions);
  if (!session || !session.user || (session.user as any).role !== 'TESTER') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }
  const userId = (session.user as any).id;
  const transactions = await prisma.walletTransaction.findMany({
    where: { userId },
    include: { campaign: true },
    orderBy: { createdAt: 'desc' },
  });
  const totalDue = transactions
    .filter((t) => t.status === 'DUE')
    .reduce((sum, t) => sum + t.amount, 0);
  const totalPaid = transactions
    .filter((t) => t.status === 'PAID')
    .reduce((sum, t) => sum + t.amount, 0);
  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-4">
        {locale === 'ar' ? 'المحفظة' : 'Wallet'}
      </h1>
      <div className="mb-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded-lg shadow">
            <p className="text-sm text-gray-500">
              {locale === 'ar' ? 'إجمالي المستحق' : 'Total Due'}
            </p>
            <p className="text-2xl font-semibold">{totalDue}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <p className="text-sm text-gray-500">
              {locale === 'ar' ? 'إجمالي المدفوع' : 'Total Paid'}
            </p>
            <p className="text-2xl font-semibold">{totalPaid}</p>
          </div>
        </div>
      </div>
      <div className="bg-white p-4 rounded-lg shadow overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="border-b">
              <th className="px-2 py-1 text-left">{locale === 'ar' ? 'الحملة' : 'Campaign'}</th>
              <th className="px-2 py-1 text-left">{locale === 'ar' ? 'المبلغ' : 'Amount'}</th>
              <th className="px-2 py-1 text-left">{locale === 'ar' ? 'الحالة' : 'Status'}</th>
              <th className="px-2 py-1 text-left">{locale === 'ar' ? 'طريقة' : 'Method'}</th>
              <th className="px-2 py-1 text-left">{locale === 'ar' ? 'ملاحظة' : 'Note'}</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((t) => (
              <tr key={t.id} className="border-b">
                <td className="px-2 py-1">{t.campaign?.name || '-'}</td>
                <td className="px-2 py-1">
                  {t.amount} {t.currency}
                </td>
                <td className="px-2 py-1">
                  {locale === 'ar'
                    ? t.status === 'DUE'
                      ? 'مستحق'
                      : 'مدفوع'
                    : t.status}
                </td>
                <td className="px-2 py-1">{t.method || '-'}</td>
                <td className="px-2 py-1">{t.note || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}