import { prisma } from '../../../../lib/prisma';
import { authOptions } from '../../../api/auth/[...nextauth]/route';
import { getServerSession } from 'next-auth/next';
import Link from 'next/link';

export default async function TesterCampaignsPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const session = await getServerSession(authOptions);
  if (!session || !session.user || (session.user as any).role !== 'TESTER') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }
  // Fetch active campaigns
  const campaigns = await prisma.campaign.findMany({
    where: { status: 'ACTIVE' },
    include: { business: true },
  });
  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-6">
        {locale === 'ar' ? 'الحملات المتاحة' : 'Available Campaigns'}
      </h1>
      <div className="grid gap-4">
        {campaigns.length === 0 && (
          <p>{locale === 'ar' ? 'لا توجد حملات متاحة حالياً' : 'No campaigns available right now'}</p>
        )}
        {campaigns.map((c) => (
          <div key={c.id} className="bg-white p-4 rounded-lg shadow-sm">
            <h2 className="text-xl font-semibold mb-2">{c.name}</h2>
            <p className="text-sm text-gray-700 mb-2">
              {c.description?.slice(0, 120)}
            </p>
            <p className="text-sm text-gray-500 mb-2">
              {locale === 'ar' ? 'النوع' : 'Type'}: {c.type}
            </p>
            <p className="text-sm text-gray-500">
              {locale === 'ar' ? 'صاحب الحملة' : 'Business'}: {c.business?.name || c.business?.email}
            </p>
            <div className="mt-3">
              <Link
                href={`/${locale}/tester/campaigns/${c.id}`}
                className="text-primary underline"
              >
                {locale === 'ar' ? 'تفاصيل' : 'Details'}
              </Link>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}