"use client";
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

export default function CampaignDetailPage({ params }: { params: { locale: string; id: string } }) {
  const { locale, id } = params;
  const { data: session } = useSession();
  const [campaign, setCampaign] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [application, setApplication] = useState<any>(null);
  const [reviewRating, setReviewRating] = useState<number>(5);
  const [reviewComment, setReviewComment] = useState<string>('');
  const [socialPlatform, setSocialPlatform] = useState<string>('INSTAGRAM');
  const [socialPostUrl, setSocialPostUrl] = useState<string>('');
  const [screenshotPath, setScreenshotPath] = useState<string>('');
  const [message, setMessage] = useState<string | null>(null);
  const router = useRouter();

  // Fetch campaign details
  useEffect(() => {
    async function fetchCampaign() {
      try {
        const res = await fetch(`/api/campaigns/${id}`);
        if (!res.ok) {
          throw new Error('Failed to load campaign');
        }
        const data = await res.json();
        setCampaign(data);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }
    fetchCampaign();
  }, [id]);

  // Fetch user application for this campaign
  useEffect(() => {
    async function fetchApplication() {
      if (!session || !session.user) return;
      try {
        const res = await fetch(`/api/applications?testerId=${(session.user as any).id}`);
        if (res.ok) {
          const data = await res.json();
          const app = data.find((a: any) => a.campaignId === parseInt(id));
          setApplication(app || null);
        }
      } catch (err) {
        console.error(err);
      }
    }
    fetchApplication();
  }, [session, id]);

  const handleApply = async () => {
    try {
      const res = await fetch(`/api/campaigns/${id}/apply`, {
        method: 'POST',
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Failed to apply');
      } else {
        // refresh application state
        setApplication({ status: 'PENDING' });
        setMessage(locale === 'ar' ? 'تم التقديم بنجاح' : 'Applied successfully');
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  const submitReview = async () => {
    if (!application) return;
    try {
      const res = await fetch(`/api/applications/${application.id}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ratingOverall: reviewRating, answersJson: {}, comment: reviewComment }),
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || 'Failed to submit review');
      } else {
        setMessage(locale === 'ar' ? 'تم إرسال المراجعة' : 'Review submitted');
        // Update application status
        setApplication({ ...application, status: 'AWAITING_REVIEW', review: data });
      }
    } catch (err: any) {
      console.error(err);
    }
  };

  const submitSocialPost = async () => {
    if (!application) return;
    try {
      const res = await fetch('/api/social-posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ campaignId: campaign.id, platform: socialPlatform, postUrl: socialPostUrl, screenshotPath }),
      });
      const data = await res.json();
      if (!res.ok) {
        alert(data.error || 'Failed to submit social post');
      } else {
        setMessage(locale === 'ar' ? 'تم إرسال المنشور الاجتماعي' : 'Social post submitted');
      }
    } catch (err: any) {
      console.error(err);
    }
  };

  if (loading) {
    return <p className="p-4">{locale === 'ar' ? 'جارٍ التحميل...' : 'Loading...'}</p>;
  }
  if (error || !campaign) {
    return <p className="p-4 text-red-600">{error || 'Not found'}</p>;
  }
  const hasApplied = !!application;
  const status = application?.status;

  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <Link href={`/${locale}/tester/campaigns`} className="text-primary underline">
        {locale === 'ar' ? 'العودة' : 'Back'}
      </Link>
      <div className="bg-white p-6 rounded-lg shadow-md mt-4">
        <h1 className="text-2xl font-semibold mb-4">{campaign.name}</h1>
        <p className="mb-2 text-gray-700">{campaign.description}</p>
        <p className="mb-2 text-sm text-gray-500">
          {locale === 'ar' ? 'النوع' : 'Type'}: {campaign.type}
        </p>
        <p className="mb-2 text-sm text-gray-500">
          {locale === 'ar' ? 'المدينة' : 'City'}: {campaign.city || '-'}
        </p>
        {!hasApplied && (
          <button
            onClick={handleApply}
            className="mt-4 px-4 py-2 bg-primary text-white rounded-md"
          >
            {locale === 'ar' ? 'تقديم طلب' : 'Apply'}
          </button>
        )}
        {hasApplied && (
          <div className="mt-4">
            <p className="text-sm mb-2">
              {locale === 'ar' ? 'حالة الطلب' : 'Application Status'}: {status}
            </p>
            {status === 'ACCEPTED' && !application.review && (
              <div className="mt-4">
                <h3 className="font-semibold mb-2">
                  {locale === 'ar' ? 'إرسال مراجعة' : 'Submit Review'}
                </h3>
                <label className="block mb-1 text-sm">
                  {locale === 'ar' ? 'التقييم العام' : 'Overall Rating'}
                </label>
                <select
                  value={reviewRating}
                  onChange={(e) => setReviewRating(parseInt(e.target.value))}
                  className="border rounded px-2 py-1 mb-2"
                >
                  {[1, 2, 3, 4, 5].map((n) => (
                    <option key={n} value={n}>{n}</option>
                  ))}
                </select>
                <label className="block mb-1 text-sm">
                  {locale === 'ar' ? 'تعليق' : 'Comment'}
                </label>
                <textarea
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  className="border rounded px-2 py-1 w-full mb-2"
                />
                <button
                  onClick={submitReview}
                  className="px-4 py-2 bg-blue-500 text-white rounded"
                >
                  {locale === 'ar' ? 'إرسال' : 'Submit'}
                </button>
              </div>
            )}
            {campaign.socialRequired && (
              <div className="mt-4">
                <h3 className="font-semibold mb-2">
                  {locale === 'ar' ? 'إرسال منشور اجتماعي' : 'Submit Social Post'}
                </h3>
                <label className="block mb-1 text-sm">
                  {locale === 'ar' ? 'المنصة' : 'Platform'}
                </label>
                <select
                  value={socialPlatform}
                  onChange={(e) => setSocialPlatform(e.target.value)}
                  className="border rounded px-2 py-1 mb-2"
                >
                  <option value="INSTAGRAM">Instagram</option>
                  <option value="TIKTOK">TikTok</option>
                  <option value="X">X</option>
                  <option value="SNAPCHAT">Snapchat</option>
                  <option value="OTHER">Other</option>
                </select>
                <label className="block mb-1 text-sm">
                  {locale === 'ar' ? 'رابط المنشور' : 'Post URL'}
                </label>
                <input
                  type="text"
                  value={socialPostUrl}
                  onChange={(e) => setSocialPostUrl(e.target.value)}
                  className="border rounded px-2 py-1 w-full mb-2"
                />
                <label className="block mb-1 text-sm">
                  {locale === 'ar' ? 'مسار الصورة (اختياري)' : 'Screenshot Path (optional)'}
                </label>
                <input
                  type="text"
                  value={screenshotPath}
                  onChange={(e) => setScreenshotPath(e.target.value)}
                  className="border rounded px-2 py-1 w-full mb-2"
                />
                <button
                  onClick={submitSocialPost}
                  className="px-4 py-2 bg-blue-500 text-white rounded"
                >
                  {locale === 'ar' ? 'إرسال' : 'Submit'}
                </button>
              </div>
            )}
            {message && (
              <p className="mt-4 text-green-600 text-sm">{message}</p>
            )}
          </div>
        )}
      </div>
    </main>
  );
}