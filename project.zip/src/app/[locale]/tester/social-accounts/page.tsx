"use client";
import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

type SocialAccount = {
  id: number;
  platform: string;
  username: string;
  profileUrl: string;
  followersCount: number;
};

export default function SocialAccountsPage({ params }: { params: { locale: string } }) {
  const { locale } = params;
  const { data: session } = useSession();
  const router = useRouter();
  const [accounts, setAccounts] = useState<SocialAccount[]>([]);
  const [form, setForm] = useState({
    platform: 'X',
    username: '',
    profileUrl: '',
    followersCount: '',
  });
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!session) return;
    if ((session.user as any).role !== 'TESTER') {
      router.push(`/${locale}/dashboard`);
      return;
    }
    fetchAccounts();
  }, [session]);

  async function fetchAccounts() {
    const res = await fetch('/api/social-accounts');
    if (res.ok) {
      const data = await res.json();
      setAccounts(data);
    }
  }

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/social-accounts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          platform: form.platform,
          username: form.username,
          profileUrl: form.profileUrl,
          followersCount: parseInt(form.followersCount || '0'),
        }),
      });
      if (!res.ok) {
        const data = await res.json();
        setError(data.error || 'Failed to add');
      } else {
        setForm({ platform: 'X', username: '', profileUrl: '', followersCount: '' });
        fetchAccounts();
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Delete this account?')) return;
    const res = await fetch(`/api/social-accounts/${id}`, { method: 'DELETE' });
    if (res.ok) {
      fetchAccounts();
    }
  };

  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-4">
        {locale === 'ar' ? 'حسابات التواصل' : 'Social Media Accounts'}
      </h1>
      <div className="bg-white p-4 rounded-lg shadow mb-6">
        <h2 className="text-lg font-semibold mb-2">
          {locale === 'ar' ? 'أضف حسابًا جديدًا' : 'Add New Account'}
        </h2>
        {error && <p className="text-red-600 mb-2">{error}</p>}
        <form onSubmit={handleAdd} className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <label className="block text-sm mb-1" htmlFor="platform">
              {locale === 'ar' ? 'المنصة' : 'Platform'}
            </label>
            <select
              id="platform"
              name="platform"
              value={form.platform}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            >
              <option value="X">X</option>
              <option value="TIKTOK">TikTok</option>
              <option value="INSTAGRAM">Instagram</option>
              <option value="SNAPCHAT">Snapchat</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
          <div>
            <label className="block text-sm mb-1" htmlFor="username">
              {locale === 'ar' ? 'اسم المستخدم' : 'Username'}
            </label>
            <input
              type="text"
              id="username"
              name="username"
              value={form.username}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
              required
            />
          </div>
          <div>
            <label className="block text-sm mb-1" htmlFor="profileUrl">
              {locale === 'ar' ? 'رابط الحساب' : 'Profile URL'}
            </label>
            <input
              type="url"
              id="profileUrl"
              name="profileUrl"
              value={form.profileUrl}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
              required
            />
          </div>
          <div>
            <label className="block text-sm mb-1" htmlFor="followersCount">
              {locale === 'ar' ? 'عدد المتابعين' : 'Followers'}
            </label>
            <input
              type="number"
              id="followersCount"
              name="followersCount"
              value={form.followersCount}
              onChange={handleChange}
              className="w-full border rounded-md px-3 py-2"
            />
          </div>
          <div className="col-span-full flex justify-end">
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-primary text-white rounded-md"
            >
              {locale === 'ar' ? 'إضافة' : 'Add'}
            </button>
          </div>
        </form>
      </div>
      <div className="bg-white p-4 rounded-lg shadow">
        <h2 className="text-lg font-semibold mb-2">
          {locale === 'ar' ? 'حساباتي' : 'My Accounts'}
        </h2>
        {accounts.length === 0 && (
          <p>{locale === 'ar' ? 'لا توجد حسابات' : 'No accounts'}</p>
        )}
        {accounts.length > 0 && (
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="px-2 py-1 text-left">{locale === 'ar' ? 'المنصة' : 'Platform'}</th>
                <th className="px-2 py-1 text-left">{locale === 'ar' ? 'اسم المستخدم' : 'Username'}</th>
                <th className="px-2 py-1 text-left">{locale === 'ar' ? 'عدد المتابعين' : 'Followers'}</th>
                <th className="px-2 py-1 text-left">{locale === 'ar' ? 'إجراء' : 'Action'}</th>
              </tr>
            </thead>
            <tbody>
              {accounts.map((acc) => (
                <tr key={acc.id} className="border-b">
                  <td className="px-2 py-1">{acc.platform}</td>
                  <td className="px-2 py-1">{acc.username}</td>
                  <td className="px-2 py-1">{acc.followersCount}</td>
                  <td className="px-2 py-1">
                    <button
                      onClick={() => handleDelete(acc.id)}
                      className="text-red-600 underline"
                    >
                      {locale === 'ar' ? 'حذف' : 'Delete'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </main>
  );
}