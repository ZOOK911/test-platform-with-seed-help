"use client";

import { useEffect, useState } from 'react';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

interface Application {
  id: number;
  status: string;
  createdAt: string;
  campaign: {
    id: number;
    name: string;
    startDate: string;
    endDate: string;
    status: string;
  };
}

interface Campaign {
  id: number;
  name: string;
  city: string | null;
  requiredLevelMin: number | null;
  requiredLevelMax: number | null;
  startDate: string;
  endDate: string;
}

export default function TesterDashboardPage({
  params,
}: {
  params: { locale: string };
}) {
  const { locale } = params;
  const { data: session } = useSession();
  const [openApps, setOpenApps] = useState<Application[]>([]);
  const [recommended, setRecommended] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchOverview() {
      try {
        const res = await fetch('/api/dashboard/tester');
        if (res.ok) {
          const data = await res.json();
          setOpenApps(data.openApplications || []);
          setRecommended(data.recommendedCampaigns || []);
        }
      } finally {
        setLoading(false);
      }
    }
    fetchOverview();
  }, []);

  if (!session || !(session as any).user || (session.user as any).role !== 'TESTER') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>{locale === 'ar' ? 'غير مصرح' : 'Not authorized'}</p>
      </div>
    );
  }

  return (
    <main className="min-h-screen px-4 py-8 bg-gray-100">
      <h1 className="text-3xl font-bold mb-6">
        {locale === 'ar' ? 'لوحة المختبر' : 'Tester Dashboard'}
      </h1>
      {loading ? (
        <p>{locale === 'ar' ? 'جاري التحميل...' : 'Loading...'}</p>
      ) : (
        <>
          {/* Open Applications Section */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-2">
              {locale === 'ar' ? 'طلباتي' : 'My Applications'}
            </h2>
            {openApps.length === 0 ? (
              <p>
                {locale === 'ar'
                  ? 'لا توجد طلبات حالية'
                  : 'You have no current applications.'}
              </p>
            ) : (
              <div className="overflow-x-auto bg-white rounded shadow p-4">
                <table className="min-w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="px-2 py-1 text-left">
                        {locale === 'ar' ? 'الحملة' : 'Campaign'}
                      </th>
                      <th className="px-2 py-1 text-left">
                        {locale === 'ar' ? 'الحالة' : 'Status'}
                      </th>
                      <th className="px-2 py-1 text-left">
                        {locale === 'ar' ? 'المدة' : 'Duration'}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {openApps.map((app) => (
                      <tr key={app.id} className="border-b">
                        <td className="px-2 py-1">
                          <Link
                            href={`/${locale}/tester/campaigns/${app.campaign.id}`}
                            className="text-blue-600 underline"
                          >
                            {app.campaign.name}
                          </Link>
                        </td>
                        <td className="px-2 py-1">{app.status}</td>
                        <td className="px-2 py-1">
                          {new Date(app.campaign.startDate).toLocaleDateString(locale)} –{' '}
                          {new Date(app.campaign.endDate).toLocaleDateString(locale)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
          {/* Recommended campaigns Section */}
          <div className="mb-8">
            <h2 className="text-xl font-semibold mb-2">
              {locale === 'ar' ? 'حملات مقترحة لك' : 'Recommended Campaigns'}
            </h2>
            {recommended.length === 0 ? (
              <p>
                {locale === 'ar'
                  ? 'لا توجد حملات مناسبة الآن'
                  : 'No recommendations at this time.'}
              </p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {recommended.map((c) => (
                  <div key={c.id} className="bg-white p-4 rounded shadow">
                    <h3 className="text-lg font-semibold mb-1">{c.name}</h3>
                    <p className="text-sm text-gray-600 mb-1">
                      {c.city ? c.city : locale === 'ar' ? 'المدينة غير محددة' : 'No city specified'}
                    </p>
                    <p className="text-sm text-gray-600 mb-2">
                      {new Date(c.startDate).toLocaleDateString(locale)} –{' '}
                      {new Date(c.endDate).toLocaleDateString(locale)}
                    </p>
                    <Link
                      href={`/${locale}/tester/campaigns/${c.id}`}
                      className="text-blue-600 underline"
                    >
                      {locale === 'ar' ? 'تفاصيل الحملة' : 'View Details'}
                    </Link>
                  </div>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </main>
  );
}