import Link from 'next/link';
import { useTranslations } from '../../lib/i18n';

export default function Home({ params }: { params: { locale: string } }) {
  // We don't fetch translations here; we will rely on static labels for demonstration.
  const { locale } = params;
  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-4 py-8 bg-gradient-to-br from-primary-light to-secondary-light">
      <h1 className="text-4xl font-bold mb-4 text-center">
        {locale === 'ar'
          ? 'منصة الاختبار والتأثير'
          : 'Testing & Influencer Platform'}
      </h1>
      <p className="mb-6 text-center max-w-xl">
        {locale === 'ar'
          ? 'انضم كمتجر أو كمؤثر/مختبر لتجربة منتجات وخدمات حقيقية وتقديم تقييمات واقعية.'
          : 'Join as a business or as a tester/influencer to try real products and services and provide authentic reviews.'}
      </p>
      <div className="flex space-x-4 rtl:space-x-reverse">
        <Link
          href={`/${locale}/auth/register?role=tester`}
          className="px-4 py-2 rounded-md bg-primary text-white hover:bg-primary-dark"
        >
          {locale === 'ar' ? 'تسجيل كمؤثر' : 'Register as Tester'}
        </Link>
        <Link
          href={`/${locale}/auth/register?role=business`}
          className="px-4 py-2 rounded-md bg-secondary text-white hover:bg-secondary-dark"
        >
          {locale === 'ar' ? 'تسجيل كعمل تجاري' : 'Register as Business'}
        </Link>
      </div>
      <div className="mt-4">
        <Link
          href={`/${locale}/auth/login`}
          className="underline text-sm text-gray-800 hover:text-gray-600"
        >
          {locale === 'ar' ? 'تسجيل الدخول' : 'Already have an account? Login'}
        </Link>
      </div>
    </main>
  );
}