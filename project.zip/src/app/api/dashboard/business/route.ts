import { NextResponse } from 'next/server';
import { prisma } from '../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]/route';

// GET handler to return summary metrics for a business dashboard.
// Metrics include total paid revenue, number of active campaigns, applications this month,
// and the average rating across all reviews on the business's campaigns.
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || !session.user || (session.user as any).role !== 'BUSINESS') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const businessId = (session.user as any).id as number;
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const [revenueData, activeCampaignsCount, applicationsCount, avgRatingData] =
    await Promise.all([
      prisma.walletTransaction.aggregate({
        _sum: { amount: true },
        where: {
          status: 'PAID',
          campaign: { businessId },
        },
      }),
      prisma.campaign.count({
        where: {
          businessId,
          status: { in: ['ACTIVE', 'IN_PROGRESS'] },
        },
      }),
      prisma.campaignApplication.count({
        where: {
          campaign: { businessId },
          createdAt: { gte: startOfMonth },
        },
      }),
      prisma.review.aggregate({
        _avg: { ratingOverall: true },
        where: { campaign: { businessId } },
      }),
    ]);
  const totalRevenue = revenueData._sum.amount ?? 0;
  const averageRating = avgRatingData._avg.ratingOverall ?? 0;
  return NextResponse.json({
    totalRevenue,
    activeCampaigns: activeCampaignsCount,
    applicationsThisMonth: applicationsCount,
    averageRating,
  });
}