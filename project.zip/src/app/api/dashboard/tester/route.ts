import { NextResponse } from 'next/server';
import { prisma } from '../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]/route';

// GET handler to return overview information for a tester dashboard.
// This includes open (non-completed) applications and a small set of recommended
// campaigns based on the tester's level and city. Campaigns the tester has
// already applied to are excluded from recommendations. Only testers can
// access this endpoint.
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || !session.user || (session.user as any).role !== 'TESTER') {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const testerId = (session.user as any).id as number;
  const tester = await prisma.user.findUnique({
    where: { id: testerId },
    select: {
      id: true,
      level: true,
      city: true,
    },
  });
  if (!tester) {
    return NextResponse.json({ error: 'Tester not found' }, { status: 404 });
  }
  // Fetch non-completed applications for this tester along with campaign info
  const openApplications = await prisma.campaignApplication.findMany({
    where: {
      testerId,
      status: { not: 'COMPLETED' },
    },
    include: {
      campaign: true,
    },
    orderBy: { createdAt: 'desc' },
  });
  // Build filters for recommended campaigns
  const level = tester.level ?? 0;
  const city = tester.city;
  // Determine campaign level range filters; null bounds mean no restriction
  const recommendedCampaigns = await prisma.campaign.findMany({
    where: {
      status: 'ACTIVE',
      // Exclude campaigns where tester already applied
      applications: {
        none: { testerId },
      },
      AND: [
        {
          OR: [
            { requiredLevelMin: null },
            { requiredLevelMin: { lte: level } },
          ],
        },
        {
          OR: [
            { requiredLevelMax: null },
            { requiredLevelMax: { gte: level } },
          ],
        },
      ],
      OR: [
        { city: null },
        city ? { city } : {},
      ],
    },
    orderBy: { startDate: 'asc' },
    take: 5,
  });
  return NextResponse.json({
    openApplications,
    recommendedCampaigns,
  });
}