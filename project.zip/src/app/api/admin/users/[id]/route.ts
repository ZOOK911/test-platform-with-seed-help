import { NextResponse } from 'next/server';
import { prisma } from '../../../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../../auth/[...nextauth]/route';

/**
 * Admin User Detail API
 *
 * PATCH: Update a user. For now, allows toggling suspended status.
 * Only admin users can perform this action.
 */
export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user || (session.user as any).role !== 'ADMIN') {
    return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
  }
  const id = parseInt(params.id);
  if (isNaN(id)) {
    return NextResponse.json({ error: 'Invalid user ID' }, { status: 400 });
  }
  let body: any;
  try {
    body = await request.json();
  } catch (err) {
    body = {};
  }
  const { suspended } = body;
  if (suspended === undefined) {
    return NextResponse.json({ error: 'suspended field is required' }, { status: 400 });
  }
  try {
    const updated = await prisma.user.update({
      where: { id },
      data: { suspended: !!suspended },
    });
    return NextResponse.json(updated);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update user' }, { status: 500 });
  }
}