import { NextResponse } from 'next/server';
import { prisma } from '../../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]/route';

/**
 * Admin Users API
 *
 * GET: List all users. Only accessible to admin users. Returns
 * an array of users with their basic information and counts of campaigns
 * and applications where appropriate.
 */
export async function GET(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user || (session.user as any).role !== 'ADMIN') {
    return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
  }
  try {
    const users = await prisma.user.findMany({
      include: {
        businessProfile: true,
        socialAccounts: true,
        _count: {
          select: {
            campaigns: true,
            campaignApplications: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(users);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch users' }, { status: 500 });
  }
}