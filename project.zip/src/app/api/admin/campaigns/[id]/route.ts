import { NextResponse } from 'next/server';
import { prisma } from '../../../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../../auth/[...nextauth]/route';

/**
 * Admin Campaign Detail API
 *
 * PATCH: Update a campaign. Currently supports updating status and testersNeeded.
 * Only accessible to admin.
 */
export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user || (session.user as any).role !== 'ADMIN') {
    return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
  }
  const id = parseInt(params.id);
  if (isNaN(id)) {
    return NextResponse.json({ error: 'Invalid campaign ID' }, { status: 400 });
  }
  let body: any;
  try {
    body = await request.json();
  } catch (err) {
    body = {};
  }
  const { status, testersNeeded } = body;
  if (!status && testersNeeded === undefined) {
    return NextResponse.json({ error: 'Nothing to update' }, { status: 400 });
  }
  try {
    const updated = await prisma.campaign.update({
      where: { id },
      data: {
        ...(status ? { status } : {}),
        ...(testersNeeded !== undefined ? { testersNeeded: parseInt(testersNeeded) } : {}),
      },
    });
    return NextResponse.json(updated);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update campaign' }, { status: 500 });
  }
}