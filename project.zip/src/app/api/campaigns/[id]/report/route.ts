import { NextResponse } from 'next/server';
import { prisma } from '../../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]/route';

/**
 * Campaign Report API
 *
 * GET: Generate a CSV report for a campaign. Includes applicants, their
 * status, ratings, comments, and social posts. Only accessible to the
 * business owner of the campaign or admins.
 */
export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const { id } = params;
  const campaignId = parseInt(id);
  if (isNaN(campaignId)) {
    return NextResponse.json({ error: 'Invalid campaign ID' }, { status: 400 });
  }
  const userId = (session.user as any).id;
  const role = (session.user as any).role;
  try {
    const campaign = await prisma.campaign.findUnique({
      where: { id: campaignId },
      include: { business: true },
    });
    if (!campaign) {
      return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
    }
    // Authorization: business owner or admin
    if (role !== 'ADMIN' && campaign.businessId !== userId) {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }
    // Fetch applications and reviews for this campaign
    const applications = await prisma.campaignApplication.findMany({
      where: { campaignId },
      include: {
        tester: true,
        review: true,
      },
    });
    // Fetch social posts for this campaign and build a map by testerId
    const posts = await prisma.socialPost.findMany({
      where: { campaignId },
      select: { testerId: true, postUrl: true },
    });
    const postsMap: Record<number, string[]> = {};
    posts.forEach((p) => {
      if (!postsMap[p.testerId]) postsMap[p.testerId] = [];
      postsMap[p.testerId].push(p.postUrl);
    });
    // Build CSV header
    const header = [
      'TesterName',
      'TesterEmail',
      'Level',
      'City',
      'ApplicationStatus',
      'Rating',
      'Comment',
      'SocialPostURLs',
    ];
    const rows = applications.map((app) => {
      const tester = app.tester as any;
      const level = tester.level ?? '';
      const city = tester.city ?? '';
      const status = app.status;
      const rating = app.review?.ratingOverall ?? '';
      const comment = app.review?.comment?.replace(/\r?\n/g, ' ') ?? '';
      const urls = (postsMap[app.testerId] || []).join(';');
      return [
        tester.name || '',
        tester.email || '',
        level.toString(),
        city,
        status,
        rating.toString(),
        comment,
        urls,
      ];
    });
    const csv =
      header.join(',') +
      '\n' +
      rows
        .map((row) =>
          row
            .map((field) => {
              // Escape double quotes and wrap fields containing comma
              const s = String(field ?? '');
              if (s.includes(',') || s.includes('"') || s.includes('\n')) {
                return `"${s.replace(/"/g, '""')}"`;
              }
              return s;
            })
            .join(',')
        )
        .join('\n');
    return new NextResponse(csv, {
      status: 200,
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="campaign_${campaignId}_report.csv"`,
      },
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to generate report' }, { status: 500 });
  }
}