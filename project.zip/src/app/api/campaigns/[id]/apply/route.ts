import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]/route';
import { prisma } from '../../../../../lib/prisma';

export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const userId = (session.user as any).id;
  const userRole = (session.user as any).role;
  if (userRole !== 'TESTER') {
    return NextResponse.json({ error: 'Only testers can apply' }, { status: 403 });
  }
  const campaignId = parseInt(params.id);
  if (isNaN(campaignId)) {
    return NextResponse.json({ error: 'Invalid campaign ID' }, { status: 400 });
  }
  try {
    const campaign = await prisma.campaign.findUnique({ where: { id: campaignId } });
    if (!campaign) {
      return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
    }
    // Check if already applied
    const existing = await prisma.campaignApplication.findFirst({
      where: { campaignId, testerId: userId },
    });
    if (existing) {
      return NextResponse.json({ error: 'Already applied' }, { status: 400 });
    }
    // Check level constraints
    const tester = await prisma.user.findUnique({
      where: { id: userId },
      include: { socialAccounts: true },
    });
    const totalFollowers = tester?.socialAccounts.reduce(
      (sum, acc) => sum + acc.followersCount,
      0
    );
    const level = tester?.level;
    if (
      (campaign.requiredLevelMin && (level ?? 0) < campaign.requiredLevelMin) ||
      (campaign.requiredLevelMax && (level ?? 0) > campaign.requiredLevelMax!)
    ) {
      return NextResponse.json({ error: 'Level requirements not met' }, { status: 403 });
    }
    await prisma.campaignApplication.create({
      data: {
        campaignId,
        testerId: userId,
        status: 'PENDING',
      },
    });
    return NextResponse.json({ message: 'Application submitted' });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to apply' }, { status: 500 });
  }
}