import { NextResponse } from 'next/server';
import { prisma } from '../../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../../auth/[...nextauth]/route';

// GET handler returns a list of suggested testers for a given campaign.
// It only allows the business owner of the campaign (or an admin) to fetch suggestions.
export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const userRole = (session.user as any).role as string;
  const requesterId = (session.user as any).id as number;
  const campaignId = parseInt(params.id, 10);
  if (isNaN(campaignId)) {
    return NextResponse.json({ error: 'Invalid campaign id' }, { status: 400 });
  }
  const campaign = await prisma.campaign.findUnique({
    where: { id: campaignId },
    select: {
      id: true,
      businessId: true,
      requiredLevelMin: true,
      requiredLevelMax: true,
      city: true,
    },
  });
  if (!campaign) {
    return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
  }
  if (userRole !== 'BUSINESS' && userRole !== 'ADMIN') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }
  // Business users may only view suggestions for their own campaign
  if (userRole === 'BUSINESS' && campaign.businessId !== requesterId) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }
  const minLevel = campaign.requiredLevelMin ?? 0;
  // If max level is null, treat as unlimited (use a large upper bound)
  const maxLevel = campaign.requiredLevelMax ?? Number.MAX_SAFE_INTEGER;
  const testers = await prisma.user.findMany({
    where: {
      role: 'TESTER',
      suspended: false,
      level: {
        gte: minLevel,
        lte: maxLevel,
      },
      OR: [
        { city: null },
        { city: campaign.city ?? undefined },
      ],
      applications: {
        none: { campaignId },
      },
    },
    include: {
      socialAccounts: true,
    },
    take: 10,
    orderBy: { createdAt: 'desc' },
  });
  return NextResponse.json(testers);
}