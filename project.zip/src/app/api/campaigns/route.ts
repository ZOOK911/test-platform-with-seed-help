import { NextResponse } from 'next/server';
import { prisma } from '../../../lib/prisma';

// GET /api/campaigns
export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const status = url.searchParams.get('status') as any;
    const campaigns = await prisma.campaign.findMany({
      where: status ? { status } : {},
      include: { business: true },
    });
    return NextResponse.json(campaigns);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch campaigns' }, { status: 500 });
  }
}

// POST /api/campaigns
export async function POST(request: Request) {
  const { getServerSession } = await import('next-auth/next');
  const { authOptions } = await import('../auth/[...nextauth]/route');
  const session = await getServerSession(authOptions);
  if (!session || !session.user || (session.user as any).role !== 'BUSINESS') {
    return NextResponse.json({ error: 'Not authorized' }, { status: 401 });
  }
  const businessId = (session.user as any).id;
  try {
    const body = await request.json();
    const {
      name,
      type,
      description,
      objectives,
      city,
      testersNeeded,
      requiredLevelMin,
      requiredLevelMax,
      rewardType,
      rewardDescription,
      rewardAmount,
      rewardCurrency,
      socialRequired,
      socialPlatforms,
      socialPostType,
      socialMention,
      socialHashtags,
      startDate,
      endDate,
    } = body;
    // Enforce subscription campaign limit based on the business's current plan.
    const { plans } = await import('../../../lib/plans');
    const currentSub = await prisma.subscription.findFirst({
      where: {
        businessId,
        status: { not: 'CANCELLED' },
      },
      orderBy: { createdAt: 'desc' },
    });
    const plan = currentSub
      ? plans.find((p: any) => p.type === currentSub.plan)
      : plans.find((p: any) => p.type === 'FREE');
    const activeCount = await prisma.campaign.count({
      where: {
        businessId,
        status: {
          in: ['DRAFT', 'ACTIVE', 'IN_PROGRESS'],
        },
      },
    });
    if (plan && plan.campaignsLimit !== null && activeCount >= plan.campaignsLimit) {
      return NextResponse.json(
        {
          error:
            'Campaign limit reached for your subscription plan. Please upgrade to create additional campaigns.',
        },
        { status: 403 }
      );
    }
    const campaign = await prisma.campaign.create({
      data: {
        businessId,
        name,
        type,
        description,
        objectives,
        city,
        testersNeeded,
        requiredLevelMin,
        requiredLevelMax,
        rewardType,
        rewardDescription,
        rewardAmount,
        rewardCurrency,
        socialRequired,
        socialPlatforms,
        socialPostType,
        socialMention,
        socialHashtags,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        status: 'DRAFT',
      },
    });
    return NextResponse.json(campaign, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to create campaign' }, { status: 500 });
  }
}