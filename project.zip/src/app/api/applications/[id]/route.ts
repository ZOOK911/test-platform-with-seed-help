import { NextResponse } from 'next/server';
import { prisma } from '../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]/route';

/**
 * Single application API
 *
 * GET: Retrieve a specific campaign application with related tester, campaign,
 * review and social posts. Only the tester, the business owning the campaign,
 * or an admin may view.
 *
 * PATCH: Update the status of a campaign application. Only the business
 * owning the campaign or an admin may update. Allowed status transitions:
 *   - PENDING → ACCEPTED or REJECTED
 *   - ACCEPTED/AWAITING_REVIEW → COMPLETED (after review/social post verified)
 * When marking COMPLETED, this endpoint will also create a WalletTransaction
 * (status DUE) for the tester based on the campaign reward. Notifications
 * are created for the tester on each status change.
 */
export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const user = session.user as any;
  const role: string = user.role;
  const userId: number = user.id;
  const id = parseInt(params.id);
  if (isNaN(id)) {
    return NextResponse.json({ error: 'Invalid ID' }, { status: 400 });
  }
  try {
    const application = await prisma.campaignApplication.findUnique({
      where: { id },
      include: {
        tester: true,
        campaign: true,
        review: true,
      },
    });
    if (!application) {
      return NextResponse.json({ error: 'Application not found' }, { status: 404 });
    }
    // Authorization: tester can view own application; business can view if they own campaign; admin can view all
    const campaign = application.campaign;
    if (
      role === 'TESTER' && application.testerId !== userId && role !== 'ADMIN'
    ) {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }
    if (
      role === 'BUSINESS' && campaign.businessId !== userId && role !== 'ADMIN'
    ) {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }
    return NextResponse.json(application);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch application' }, { status: 500 });
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const user = session.user as any;
  const role: string = user.role;
  const userId: number = user.id;
  const id = parseInt(params.id);
  if (isNaN(id)) {
    return NextResponse.json({ error: 'Invalid ID' }, { status: 400 });
  }
  let body: any;
  try {
    body = await request.json();
  } catch (err) {
    body = {};
  }
  const { status: newStatus } = body;
  if (!newStatus) {
    return NextResponse.json({ error: 'Missing status' }, { status: 400 });
  }
  try {
    const application = await prisma.campaignApplication.findUnique({
      where: { id },
      include: { campaign: true },
    });
    if (!application) {
      return NextResponse.json({ error: 'Application not found' }, { status: 404 });
    }
    const campaign = application.campaign;
    // Only business owner or admin can update application status
    if (role === 'BUSINESS' && campaign.businessId !== userId) {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }
    if (role !== 'BUSINESS' && role !== 'ADMIN') {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }
    // Determine allowed transitions
    const currentStatus = application.status;
    const allowed: Record<string, string[]> = {
      PENDING: ['ACCEPTED', 'REJECTED'],
      ACCEPTED: ['AWAITING_REVIEW', 'COMPLETED'],
      AWAITING_REVIEW: ['COMPLETED'],
      REJECTED: [],
      COMPLETED: [],
    } as any;
    const allowedTransitions = allowed[currentStatus] || [];
    if (!allowedTransitions.includes(newStatus)) {
      return NextResponse.json({ error: `Cannot change status from ${currentStatus} to ${newStatus}` }, { status: 400 });
    }
    // When marking COMPLETED, ensure a review exists or social requirement conditions are met
    if (newStatus === 'COMPLETED') {
      // Create a wallet transaction for the tester if not exists for this application
      const existingTx = await prisma.walletTransaction.findFirst({
        where: { campaignId: application.campaignId, userId: application.testerId },
      });
      if (!existingTx) {
        await prisma.walletTransaction.create({
          data: {
            userId: application.testerId,
            campaignId: application.campaignId,
            amount: campaign.rewardAmount || 0,
            currency: campaign.rewardCurrency || 'SAR',
            status: 'DUE',
          },
        });
      }
    }
    // Update application status
    const updated = await prisma.campaignApplication.update({
      where: { id },
      data: { status: newStatus },
    });
    // Create notification for tester
    const notificationTitleMap: Record<string, string> = {
      ACCEPTED: 'تم قبول طلبك',
      REJECTED: 'تم رفض طلبك',
      COMPLETED: 'تم إكمال طلبك',
      AWAITING_REVIEW: 'بانتظار مراجعتك',
    };
    const notificationBodyMap: Record<string, string> = {
      ACCEPTED: `تم قبولك في حملة ${campaign.name}.`,
      REJECTED: `تم رفض طلبك في حملة ${campaign.name}.`,
      COMPLETED: `تم إكمال مشاركتك في حملة ${campaign.name}.`,
      AWAITING_REVIEW: `يرجى تقديم مراجعتك لحملة ${campaign.name}.`,
    };
    const title = notificationTitleMap[newStatus] || `Status updated to ${newStatus}`;
    const bodyMsg = notificationBodyMap[newStatus] || '';
    await prisma.notification.create({
      data: {
        userId: application.testerId,
        type: 'APPLICATION_STATUS',
        title,
        body: bodyMsg,
      },
    });
    return NextResponse.json(updated);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update application' }, { status: 500 });
  }
}