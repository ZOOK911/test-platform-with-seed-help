import { NextResponse } from 'next/server';
import { prisma } from '../../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../../auth/[...nextauth]/route';

/**
 * Submit a review for a campaign application.
 *
 * Only the tester who owns the application may submit a review. The
 * application must have status ACCEPTED. Upon submission, a Review record
 * is created and the application status is set to AWAITING_REVIEW. A
 * notification is sent to the business owner informing them that a review
 * is ready for approval.
 */
export async function POST(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const user = session.user as any;
  const role: string = user.role;
  const userId: number = user.id;
  if (role !== 'TESTER') {
    return NextResponse.json({ error: 'Only testers can submit reviews' }, { status: 403 });
  }
  const appId = parseInt(params.id);
  if (isNaN(appId)) {
    return NextResponse.json({ error: 'Invalid application ID' }, { status: 400 });
  }
  let body: any;
  try {
    body = await request.json();
  } catch (err) {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }
  const { ratingOverall, answersJson, comment } = body;
  if (!ratingOverall || typeof ratingOverall !== 'number') {
    return NextResponse.json({ error: 'ratingOverall is required and must be a number' }, { status: 400 });
  }
  try {
    const application = await prisma.campaignApplication.findUnique({
      where: { id: appId },
      include: { campaign: true },
    });
    if (!application) {
      return NextResponse.json({ error: 'Application not found' }, { status: 404 });
    }
    if (application.testerId !== userId) {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }
    if (application.status !== 'ACCEPTED') {
      return NextResponse.json({ error: 'Cannot submit review unless application is accepted' }, { status: 400 });
    }
    // Create review record
    const review = await prisma.review.create({
      data: {
        campaignId: application.campaignId,
        testerId: userId,
        ratingOverall,
        answersJson: answersJson || {},
        comment: comment || null,
      },
    });
    // Update application status to AWAITING_REVIEW
    await prisma.campaignApplication.update({
      where: { id: appId },
      data: { status: 'AWAITING_REVIEW' },
    });
    // Notify business owner
    const campaign = application.campaign;
    await prisma.notification.create({
      data: {
        userId: campaign.businessId,
        type: 'REVIEW_SUBMITTED',
        title: 'تم إرسال مراجعة جديدة',
        body: `أرسل المختبر مراجعة لحملة ${campaign.name}.`,
      },
    });
    return NextResponse.json(review, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to submit review' }, { status: 500 });
  }
}