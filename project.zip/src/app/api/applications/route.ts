import { NextResponse } from 'next/server';
import { prisma } from '../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]/route';

/**
 * Applications API
 *
 * This route returns a list of campaign applications. It supports filtering by
 * campaignId (for business/admin) and testerId (for tester/admin). Only
 * authenticated users may call this endpoint. Business users may only fetch
 * applications for campaigns they own. Testers may only fetch their own
 * applications. Admins may fetch any applications.
 */
export async function GET(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const user = session.user as any;
  const role: string = user.role;
  const userId: number = user.id;
  const url = new URL(request.url);
  const campaignIdParam = url.searchParams.get('campaignId');
  const testerIdParam = url.searchParams.get('testerId');

  try {
    // Filter by campaign
    if (campaignIdParam) {
      const campaignId = parseInt(campaignIdParam);
      if (isNaN(campaignId)) {
        return NextResponse.json({ error: 'Invalid campaignId' }, { status: 400 });
      }
      const campaign = await prisma.campaign.findUnique({ where: { id: campaignId } });
      if (!campaign) {
        return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
      }
      // Only the business owner of the campaign or admin can list applications
      if (role === 'BUSINESS' && campaign.businessId !== userId) {
        return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
      }
      // Fetch applications including tester profile and review
      const applications = await prisma.campaignApplication.findMany({
        where: { campaignId },
        include: {
          tester: true,
          review: true,
        },
        orderBy: { createdAt: 'asc' },
      });
      return NextResponse.json(applications);
    }
    // Filter by tester
    if (testerIdParam) {
      const testerId = parseInt(testerIdParam);
      if (isNaN(testerId)) {
        return NextResponse.json({ error: 'Invalid testerId' }, { status: 400 });
      }
      // Only the tester or admin can query tester applications
      if (role === 'TESTER' && testerId !== userId) {
        return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
      }
      const applications = await prisma.campaignApplication.findMany({
        where: { testerId },
        include: {
          campaign: true,
          review: true,
        },
        orderBy: { createdAt: 'asc' },
      });
      return NextResponse.json(applications);
    }
    // If no filters provided, only admin can list all applications
    if (role !== 'ADMIN') {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }
    const applications = await prisma.campaignApplication.findMany({
      include: {
        tester: true,
        campaign: true,
        review: true,
      },
      orderBy: { createdAt: 'asc' },
    });
    return NextResponse.json(applications);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch applications' }, { status: 500 });
  }
}