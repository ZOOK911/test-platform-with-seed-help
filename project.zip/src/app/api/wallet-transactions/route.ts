import { NextResponse } from 'next/server';
import { prisma } from '../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]/route';

/**
 * Wallet Transactions API
 *
 * GET: List wallet transactions for the current user.
 * - Tester: returns transactions where userId = session user id.
 * - Business: returns transactions for campaigns belonging to the business.
 * - Admin: returns all transactions.
 * Optional query param `status` can filter by DUE or PAID.
 */
export async function GET(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const { role, id } = session.user as any;
  const url = new URL(request.url);
  const status = url.searchParams.get('status');
  const where: any = {};
  if (status && (status === 'DUE' || status === 'PAID')) {
    where.status = status;
  }
  try {
    let transactions;
    if (role === 'TESTER') {
      transactions = await prisma.walletTransaction.findMany({
        where: { ...where, userId: id },
        include: { campaign: true, user: true },
        orderBy: { createdAt: 'desc' },
      });
    } else if (role === 'BUSINESS') {
      transactions = await prisma.walletTransaction.findMany({
        where: {
          ...where,
          campaign: {
            businessId: id,
          },
        },
        include: { campaign: true, user: true },
        orderBy: { createdAt: 'desc' },
      });
    } else if (role === 'ADMIN') {
      transactions = await prisma.walletTransaction.findMany({
        where,
        include: { campaign: true, user: true },
        orderBy: { createdAt: 'desc' },
      });
    } else {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }
    return NextResponse.json(transactions);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch transactions' }, { status: 500 });
  }
}