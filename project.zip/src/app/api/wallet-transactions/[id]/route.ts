import { NextResponse } from 'next/server';
import { prisma } from '../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]/route';

/**
 * Wallet Transaction API
 *
 * PATCH: Mark a wallet transaction as paid. Only the business owner of the
 * associated campaign or an admin may perform this action. The request body
 * should include method (string) and optional note. The status will be set
 * to PAID, paidAt set to now, and paidByUserId set to current user.
 */
export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const user = session.user as any;
  const role: string = user.role;
  const userId: number = user.id;
  const id = parseInt(params.id);
  if (isNaN(id)) {
    return NextResponse.json({ error: 'Invalid transaction ID' }, { status: 400 });
  }
  let body: any;
  try {
    body = await request.json();
  } catch (err) {
    body = {};
  }
  const { method, note } = body;
  if (!method) {
    return NextResponse.json({ error: 'method is required' }, { status: 400 });
  }
  try {
    const transaction = await prisma.walletTransaction.findUnique({
      where: { id },
      include: { campaign: true },
    });
    if (!transaction) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 });
    }
    // Authorization: business owner of campaign or admin
    if (role === 'BUSINESS' && transaction.campaign?.businessId !== userId) {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }
    if (role !== 'BUSINESS' && role !== 'ADMIN') {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }
    // Only update if status is DUE
    if (transaction.status !== 'DUE') {
      return NextResponse.json({ error: 'Transaction is already paid' }, { status: 400 });
    }
    const updated = await prisma.walletTransaction.update({
      where: { id },
      data: {
        status: 'PAID',
        paidAt: new Date(),
        paidByUserId: userId,
        method,
        note: note || null,
      },
    });
    // Notify tester of payment
    await prisma.notification.create({
      data: {
        userId: transaction.userId,
        type: 'PAYMENT_PAID',
        title: 'تم دفع مكافأتك',
        body: `تم دفع مكافأتك لحملة ${transaction.campaign?.name || ''}.`,
      },
    });
    return NextResponse.json(updated);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update transaction' }, { status: 500 });
  }
}