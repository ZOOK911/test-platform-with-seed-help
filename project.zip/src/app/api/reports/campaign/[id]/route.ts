import { NextResponse } from 'next/server';
import { prisma } from '../../../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../../auth/[...nextauth]/route';

// GET handler providing a detailed report for a specific campaign.
// The report includes applicant counts, completion counts, average rating,
// rating distribution, per-question statistics from answersJson, and a list
// of testers with their reviews and social post links. Accessible to the
// business owner of the campaign or administrators.
export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const userId = (session.user as any).id as number;
  const role = (session.user as any).role as string;
  const campaignId = parseInt(params.id, 10);
  if (isNaN(campaignId)) {
    return NextResponse.json({ error: 'Invalid campaign id' }, { status: 400 });
  }
  const campaign = await prisma.campaign.findUnique({
    where: { id: campaignId },
    select: { id: true, businessId: true },
  });
  if (!campaign) {
    return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
  }
  if (role === 'BUSINESS' && campaign.businessId !== userId) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }
  // Count total applicants
  const applicantsCountPromise = prisma.campaignApplication.count({
    where: { campaignId },
  });
  // Count accepted or further statuses
  const acceptedCountPromise = prisma.campaignApplication.count({
    where: {
      campaignId,
      status: { in: ['ACCEPTED', 'AWAITING_REVIEW', 'COMPLETED'] },
    },
  });
  // Count completed
  const completedCountPromise = prisma.campaignApplication.count({
    where: { campaignId, status: 'COMPLETED' },
  });
  // Average rating
  const avgRatingPromise = prisma.review.aggregate({
    _avg: { ratingOverall: true },
    where: { campaignId },
  });
  // Rating distribution counts
  const ratingDistributionPromise = prisma.review.groupBy({
    by: ['ratingOverall'],
    where: { campaignId },
    _count: { _all: true },
  });
  // Fetch all reviews with testers and answersJson
  const reviewsPromise = prisma.review.findMany({
    where: { campaignId },
    include: {
      tester: true,
    },
  });
  const [applicantsCount, acceptedCount, completedCount, avgRatingData, ratingGroups, reviews] =
    await Promise.all([
      applicantsCountPromise,
      acceptedCountPromise,
      completedCountPromise,
      avgRatingPromise,
      ratingDistributionPromise,
      reviewsPromise,
    ]);
  const averageRating = avgRatingData._avg.ratingOverall ?? 0;
  // Convert rating distribution to a simple map
  const ratingCounts: Record<number, number> = {};
  for (const group of ratingGroups) {
    ratingCounts[group.ratingOverall] = group._count._all;
  }
  // Compute per-question statistics
  const answersStats: Record<string, any> = {};
  for (const review of reviews) {
    let answers: any;
    try {
      answers = review.answersJson;
    } catch (err) {
      answers = null;
    }
    if (answers && typeof answers === 'object') {
      for (const key of Object.keys(answers)) {
        const value = (answers as any)[key];
        if (value === null || value === undefined) continue;
        if (!answersStats[key]) {
          answersStats[key] = { sum: 0, count: 0, values: {} };
        }
        if (typeof value === 'number') {
          answersStats[key].sum += value;
          answersStats[key].count += 1;
        } else if (typeof value === 'boolean') {
          const boolKey = value ? 'true' : 'false';
          answersStats[key].values[boolKey] = (answersStats[key].values[boolKey] || 0) + 1;
          answersStats[key].count += 1;
        } else if (typeof value === 'string') {
          // Strings are treated as categorical
          answersStats[key].values[value] = (answersStats[key].values[value] || 0) + 1;
          answersStats[key].count += 1;
        }
      }
    }
  }
  // Compute averages for numeric questions
  const processedAnswersStats: Record<string, any> = {};
  for (const key of Object.keys(answersStats)) {
    const stat = answersStats[key];
    if (stat.sum !== undefined) {
      processedAnswersStats[key] = {
        average: stat.count ? stat.sum / stat.count : 0,
        count: stat.count,
      };
    } else {
      processedAnswersStats[key] = stat.values;
    }
  }
  // Fetch social posts for each tester in bulk
  const testerIds = reviews.map((r) => r.testerId);
  const postsByTester: Record<number, { platform: string; postUrl: string }[]> = {};
  if (testerIds.length > 0) {
    const posts = await prisma.socialPost.findMany({
      where: { campaignId, testerId: { in: testerIds } },
    });
    for (const p of posts) {
      if (!postsByTester[p.testerId]) postsByTester[p.testerId] = [];
      postsByTester[p.testerId].push({ platform: p.platform, postUrl: p.postUrl });
    }
  }
  // Construct testers list
  const testers = reviews.map((review) => {
    const tester = review.tester;
    return {
      id: tester.id,
      name: tester.name || tester.email,
      level: tester.level,
      city: tester.city,
      rating: review.ratingOverall,
      comment: review.comment,
      answers: review.answersJson,
      socialPosts: postsByTester[tester.id] || [],
    };
  });
  return NextResponse.json({
    applicantsCount,
    acceptedCount,
    completedCount,
    averageRating,
    ratingCounts,
    answersStats: processedAnswersStats,
    testers,
  });
}