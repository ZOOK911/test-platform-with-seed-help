import { NextResponse } from 'next/server';
import { prisma } from '../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]/route';

/**
 * Social Posts API
 *
 * POST: Create a social post for a campaign. Only testers may create. A
 * corresponding record is inserted with verified=false. The tester must
 * supply campaignId, platform, postUrl, and screenshotPath. A
 * notification is sent to the business owner of the campaign to verify
 * the post.
 */
export async function POST(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const user = session.user as any;
  const role: string = user.role;
  const userId: number = user.id;
  if (role !== 'TESTER') {
    return NextResponse.json({ error: 'Only testers can submit social posts' }, { status: 403 });
  }
  let body: any;
  try {
    body = await request.json();
  } catch (err) {
    return NextResponse.json({ error: 'Invalid JSON' }, { status: 400 });
  }
  const { campaignId, platform, postUrl, screenshotPath } = body;
  if (!campaignId || !platform || !postUrl) {
    return NextResponse.json({ error: 'campaignId, platform and postUrl are required' }, { status: 400 });
  }
  const cid = parseInt(campaignId);
  if (isNaN(cid)) {
    return NextResponse.json({ error: 'Invalid campaignId' }, { status: 400 });
  }
  try {
    const campaign = await prisma.campaign.findUnique({ where: { id: cid } });
    if (!campaign) {
      return NextResponse.json({ error: 'Campaign not found' }, { status: 404 });
    }
    // Create social post
    const socialPost = await prisma.socialPost.create({
      data: {
        campaignId: cid,
        testerId: userId,
        platform,
        postUrl,
        screenshotPath: screenshotPath || '',
        verified: false,
      },
    });
    // Notify business owner for verification
    await prisma.notification.create({
      data: {
        userId: campaign.businessId,
        type: 'SOCIAL_POST_SUBMITTED',
        title: 'منشور اجتماعي جديد بانتظار التحقق',
        body: `أرسل المختبر منشورًا اجتماعيًا لحملة ${campaign.name}.`,
      },
    });
    return NextResponse.json(socialPost, { status: 201 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to submit social post' }, { status: 500 });
  }
}

/**
 * GET: List social posts. Only business users (for their campaigns) or admins
 * may access this endpoint. Optional query params: `verified` (true/false)
 * and `campaignId` to filter posts.
 */
export async function GET(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const user = session.user as any;
  const role: string = user.role;
  const userId: number = user.id;
  if (role !== 'BUSINESS' && role !== 'ADMIN') {
    return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
  }
  const url = new URL(request.url);
  const verifiedParam = url.searchParams.get('verified');
  const campaignIdParam = url.searchParams.get('campaignId');
  const where: any = {};
  if (verifiedParam === 'true') where.verified = true;
  if (verifiedParam === 'false') where.verified = false;
  if (campaignIdParam) {
    const cid = parseInt(campaignIdParam);
    if (!isNaN(cid)) where.campaignId = cid;
  }
  try {
    const posts = await prisma.socialPost.findMany({
      where: {
        ...where,
        ...(role === 'BUSINESS'
          ? {
              campaign: {
                businessId: userId,
              },
            }
          : {}),
      },
      include: {
        tester: true,
        campaign: true,
      },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json(posts);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch social posts' }, { status: 500 });
  }
}