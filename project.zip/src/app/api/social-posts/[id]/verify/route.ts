import { NextResponse } from 'next/server';
import { prisma } from '../../../../lib/prisma';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../../auth/[...nextauth]/route';

/**
 * Verify or reject a social post.
 *
 * Only the business owner of the associated campaign or an admin may
 * perform this action. The request body should include { verified: boolean }.
 * When verified, the post is marked as verified=true, verifiedBy set to
 * current user, and verifiedAt set to now. A notification is sent to the
 * tester indicating the decision. If rejected, verified remains false
 * but the verifiedBy and verifiedAt fields can still be set for tracking.
 */
export async function PATCH(
  request: Request,
  { params }: { params: { id: string } }
) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const user = session.user as any;
  const role: string = user.role;
  const userId: number = user.id;
  const id = parseInt(params.id);
  if (isNaN(id)) {
    return NextResponse.json({ error: 'Invalid social post ID' }, { status: 400 });
  }
  let body: any;
  try {
    body = await request.json();
  } catch (err) {
    body = {};
  }
  const { verified } = body;
  if (verified === undefined) {
    return NextResponse.json({ error: 'verified property is required' }, { status: 400 });
  }
  try {
    const socialPost = await prisma.socialPost.findUnique({
      where: { id },
      include: { campaign: true },
    });
    if (!socialPost) {
      return NextResponse.json({ error: 'Social post not found' }, { status: 404 });
    }
    // Authorization: business owner or admin
    if (role === 'BUSINESS' && socialPost.campaign?.businessId !== userId) {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }
    if (role !== 'BUSINESS' && role !== 'ADMIN') {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }
    const updated = await prisma.socialPost.update({
      where: { id },
      data: {
        verified: !!verified,
        verifiedById: userId,
        verifiedAt: new Date(),
      },
    });
    // Notify tester of result
    await prisma.notification.create({
      data: {
        userId: updated.testerId,
        type: 'SOCIAL_POST_VERIFIED',
        title: verified ? 'تم التحقق من منشورك' : 'تم رفض منشورك',
        body: verified
          ? `تم التحقق من منشورك لحملة ${socialPost.campaign?.name || ''}.`
          : `تم رفض منشورك لحملة ${socialPost.campaign?.name || ''}.`,
      },
    });
    return NextResponse.json(updated);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to verify social post' }, { status: 500 });
  }
}