import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../auth/[...nextauth]/route';
import { prisma } from '../../../lib/prisma';
import { updateTesterLevel } from '../../../lib/level';

// GET /api/social-accounts
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const userId = (session.user as any).id;
  const accounts = await prisma.socialAccount.findMany({
    where: { userId },
  });
  return NextResponse.json(accounts);
}

// POST /api/social-accounts
export async function POST(request: Request) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const userId = (session.user as any).id;
  const body = await request.json();
  const { platform, username, profileUrl, followersCount } = body;
  if (!platform || !username || !profileUrl) {
    return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
  }
  const acc = await prisma.socialAccount.create({
    data: {
      userId,
      platform,
      username,
      profileUrl,
      followersCount: followersCount ? parseInt(followersCount) : 0,
    },
  });
  // Update level
  await updateTesterLevel(userId);
  return NextResponse.json(acc, { status: 201 });
}