import { NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { authOptions } from '../../auth/[...nextauth]/route';
import { prisma } from '../../../../lib/prisma';
import { updateTesterLevel } from '../../../../lib/level';

// PUT /api/social-accounts/[id] - update social account
export async function PUT(request: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const userId = (session.user as any).id;
  const id = parseInt(params.id);
  if (isNaN(id)) {
    return NextResponse.json({ error: 'Invalid id' }, { status: 400 });
  }
  const body = await request.json();
  const { platform, username, profileUrl, followersCount } = body;
  try {
    const account = await prisma.socialAccount.findUnique({ where: { id } });
    if (!account || account.userId !== userId) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }
    const updated = await prisma.socialAccount.update({
      where: { id },
      data: {
        platform: platform ?? account.platform,
        username: username ?? account.username,
        profileUrl: profileUrl ?? account.profileUrl,
        followersCount: followersCount !== undefined ? parseInt(followersCount) : account.followersCount,
      },
    });
    await updateTesterLevel(userId);
    return NextResponse.json(updated);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update' }, { status: 500 });
  }
}

// DELETE /api/social-accounts/[id] - delete social account
export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session || !session.user) {
    return NextResponse.json({ error: 'Not authenticated' }, { status: 401 });
  }
  const userId = (session.user as any).id;
  const id = parseInt(params.id);
  if (isNaN(id)) {
    return NextResponse.json({ error: 'Invalid id' }, { status: 400 });
  }
  try {
    const account = await prisma.socialAccount.findUnique({ where: { id } });
    if (!account || account.userId !== userId) {
      return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }
    await prisma.socialAccount.delete({ where: { id } });
    await updateTesterLevel(userId);
    return NextResponse.json({ message: 'Deleted' });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to delete' }, { status: 500 });
  }
}