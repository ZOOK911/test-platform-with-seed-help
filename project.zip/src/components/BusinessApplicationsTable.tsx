"use client";
import { useState, useEffect } from 'react';
import { useSession } from 'next-auth/react';

export interface ApplicationWithTester {
  id: number;
  status: string;
  tester: {
    id: number;
    name: string | null;
    email: string;
    level: number | null;
    city?: string | null;
  };
  review?: {
    ratingOverall: number;
  } | null;
}

interface Props {
  campaignId: number;
  locale: string;
}

export default function BusinessApplicationsTable({ campaignId, locale }: Props) {
  const { data: session } = useSession();
  const [applications, setApplications] = useState<ApplicationWithTester[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  const fetchApplications = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/applications?campaignId=${campaignId}`);
      if (res.ok) {
        const data = await res.json();
        setApplications(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (campaignId) {
      fetchApplications();
    }
  }, [campaignId]);

  const updateStatus = async (appId: number, status: string) => {
    try {
      const res = await fetch(`/api/applications/${appId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      if (res.ok) {
        fetchApplications();
      } else {
        const err = await res.json();
        alert(err.error || 'Failed to update');
      }
    } catch (err) {
      console.error(err);
    }
  };

  const t = (key: string) => {
    const translations: Record<string, { ar: string; en: string }> = {
      name: { ar: 'الاسم', en: 'Name' },
      status: { ar: 'الحالة', en: 'Status' },
      actions: { ar: 'إجراءات', en: 'Actions' },
      accept: { ar: 'قبول', en: 'Accept' },
      reject: { ar: 'رفض', en: 'Reject' },
      complete: { ar: 'اكتمال', en: 'Complete' },
      rating: { ar: 'التقييم', en: 'Rating' },
      noApplicants: { ar: 'لا يوجد متقدمون', en: 'No applicants yet' },
    };
    return translations[key] ? translations[key][locale === 'ar' ? 'ar' : 'en'] : key;
  };

  if (loading) {
    return <p>{locale === 'ar' ? 'جارٍ التحميل...' : 'Loading...'}</p>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full text-sm">
        <thead>
          <tr className="border-b">
            <th className="px-2 py-1 text-left">{t('name')}</th>
            <th className="px-2 py-1 text-left">{t('status')}</th>
            <th className="px-2 py-1 text-left">{t('rating')}</th>
            <th className="px-2 py-1 text-left">{t('actions')}</th>
          </tr>
        </thead>
        <tbody>
          {applications.map((app) => (
            <tr key={app.id} className="border-b">
              <td className="px-2 py-1">
                {app.tester.name || app.tester.email}
              </td>
              <td className="px-2 py-1">{app.status}</td>
              <td className="px-2 py-1">
                {app.review ? app.review.ratingOverall : '-'}
              </td>
              <td className="px-2 py-1 space-x-2 rtl:space-x-reverse">
                {app.status === 'PENDING' && (
                  <>
                    <button
                      onClick={() => updateStatus(app.id, 'ACCEPTED')}
                      className="px-2 py-1 bg-green-500 text-white rounded text-xs"
                    >
                      {t('accept')}
                    </button>
                    <button
                      onClick={() => updateStatus(app.id, 'REJECTED')}
                      className="px-2 py-1 bg-red-500 text-white rounded text-xs"
                    >
                      {t('reject')}
                    </button>
                  </>
                )}
                {(app.status === 'ACCEPTED' || app.status === 'AWAITING_REVIEW') && (
                  <button
                    onClick={() => updateStatus(app.id, 'COMPLETED')}
                    className="px-2 py-1 bg-blue-500 text-white rounded text-xs"
                  >
                    {t('complete')}
                  </button>
                )}
              </td>
            </tr>
          ))}
          {applications.length === 0 && (
            <tr>
              <td colSpan={4} className="text-center py-2">
                {t('noApplicants')}
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}