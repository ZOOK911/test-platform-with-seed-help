"use client";

import { useEffect, useState } from 'react';

interface Tester {
  id: number;
  name: string | null;
  email: string;
  city: string | null;
  level: number | null;
  socialAccounts: {
    platform: string;
    followersCount: number;
  }[];
}

export default function SuggestedTestersTable({
  campaignId,
  locale,
}: {
  campaignId: number;
  locale: string;
}) {
  const [testers, setTesters] = useState<Tester[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  useEffect(() => {
    async function fetchTesters() {
      try {
        const res = await fetch(`/api/campaigns/${campaignId}/suggested-testers`);
        if (res.ok) {
          const data = await res.json();
          setTesters(data);
        }
      } finally {
        setLoading(false);
      }
    }
    fetchTesters();
  }, [campaignId]);
  if (loading) {
    return <p>{locale === 'ar' ? 'جاري التحميل...' : 'Loading...'}</p>;
  }
  return (
    <div className="mt-6">
      <h2 className="text-xl font-semibold mb-2">
        {locale === 'ar' ? 'مقترحون' : 'Suggested Testers'}
      </h2>
      {testers.length === 0 ? (
        <p>{locale === 'ar' ? 'لا يوجد مقترحين' : 'No suggestions'}</p>
      ) : (
        <div className="overflow-x-auto bg-white p-4 rounded shadow">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الاسم' : 'Name'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'المدينة' : 'City'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'المستوى' : 'Level'}
                </th>
                <th className="px-2 py-1 text-left">
                  {locale === 'ar' ? 'الإجمالي' : 'Followers'}
                </th>
              </tr>
            </thead>
            <tbody>
              {testers.map((tester) => {
                const totalFollowers = tester.socialAccounts.reduce(
                  (sum, acc) => sum + (acc.followersCount || 0),
                  0
                );
                return (
                  <tr key={tester.id} className="border-b">
                    <td className="px-2 py-1">
                      {tester.name || tester.email}
                    </td>
                    <td className="px-2 py-1">{tester.city || '-'}</td>
                    <td className="px-2 py-1">{tester.level ?? '-'}</td>
                    <td className="px-2 py-1">{totalFollowers}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}