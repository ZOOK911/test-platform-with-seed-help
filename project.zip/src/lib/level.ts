/**
 * Helpers for calculating and updating tester levels based on total followers.
 */
import { prisma } from './prisma';

/**
 * Determine level based on total followers across social accounts.
 * Levels:
 *  1: 0–999
 *  2: 1,000–9,999
 *  3: 10,000–49,999
 *  4: 50,000–249,999
 *  5: 250,000+
 */
export function calculateLevel(totalFollowers: number): number {
  if (totalFollowers >= 250000) return 5;
  if (totalFollowers >= 50000) return 4;
  if (totalFollowers >= 10000) return 3;
  if (totalFollowers >= 1000) return 2;
  return 1;
}

/**
 * Recalculate and update the level for a tester based on their social accounts.
 * Returns the new level.
 */
export async function updateTesterLevel(userId: number): Promise<number> {
  const accounts = await prisma.socialAccount.findMany({
    where: { userId },
  });
  const totalFollowers = accounts.reduce((sum, acc) => sum + acc.followersCount, 0);
  const level = calculateLevel(totalFollowers);
  await prisma.user.update({
    where: { id: userId },
    data: { level },
  });
  return level;
}