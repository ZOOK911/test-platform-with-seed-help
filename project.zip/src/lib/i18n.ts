/**
 * Placeholder i18n helper. In a real application you would fetch translation
 * files and return translated strings based on the current locale.
 */
export function useTranslations() {
  return {
    t: (key: string) => key,
  };
}