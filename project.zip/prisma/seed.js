const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

/*
 * Seed script to ensure that an admin account exists in the database. It reads
 * ADMIN_EMAIL and ADMIN_PASSWORD from the environment. If not provided,
 * default values are used. Run this script with `npx prisma db seed` or via
 * `node prisma/seed.js` to create the admin user if it does not already
 * exist. Note: replace the default password in production.
 */
async function main() {
  const email = process.env.ADMIN_EMAIL || 'zook01has@gmail.com';
  const password = process.env.ADMIN_PASSWORD || 'admin1234';
  const passwordHash = await bcrypt.hash(password, 10);
  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    console.log(`Admin user with email ${email} already exists`);
    return;
  }
  await prisma.user.create({
    data: {
      email,
      passwordHash,
      role: 'ADMIN',
      name: 'Admin',
    },
  });
  console.log(`Created admin user with email ${email}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });