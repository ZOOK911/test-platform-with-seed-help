const defaultTheme = require('tailwindcss/defaultTheme');

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['var(--font-inter)', ...defaultTheme.fontFamily.sans],
      },
      colors: {
        primary: {
          light: '#f7c8e0',
          DEFAULT: '#c785e6',
          dark: '#9e55c9',
        },
        secondary: {
          light: '#c9e4f6',
          DEFAULT: '#92c7e7',
          dark: '#4a7fb3',
        },
      },
    },
  },
  plugins: [require('@tailwindcss/forms')],
};